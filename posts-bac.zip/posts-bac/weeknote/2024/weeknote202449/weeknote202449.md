---
title: WeekNote 2024-49
cover: /now/notes.png
banner: /now/notes.png
thumbnail: /now/notes.png
index_img: /now/notes.png
banner_img: /now/notes.png
date: 2024-12-06 16:44:52
published: true
breadcrumb: true
nav_tabs: true # 这就意味着页面会显示首页文章导航栏
topic: WeekNote # 专栏 e-sth or mc or WeekNote
categories:
  - WeekNote
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine date:二〇二四年十二月二日『第四十九周』 %}
<!-- line left -->
停下脚步，看看那一望无际的星空，那是浩瀚宇宙千年前的光，那是宇宙的历史，我们所看到的，多是来自亿万年前的景色
{% endpaper %}
</p></div>

## 小记

周一的天空是云山蓝的(#2f90b9)，风很轻，天上没有一丝云。晚上回家，刚出地铁站，一股寒意扑面而来，不由得抬头看了一眼天空，漆黑的夜色点缀着十来颗星。看着夜空的星图，熟悉又陌生。！那是猎户座，百光年外的蓝巨星（参宿七）发出的光芒。思绪立刻回到了奋力拼搏的高三，黎明十分，洗漱完后带上眼镜看向天空，七颗北斗星印在深邃的画布上我盯着它许久，那是我第一次看见星图，第一次看见北斗七星。那一年，一连好几天都有，他就那样高高的挂着。奶奶说七星会随着最亮的勺柄转动。这几天我起床后都会去看看，看它是不是真的在转动。

{% image /headimg/weeknote/202449/4.png 猎户座 %}

又是平凡的一个工作日，下了公交过了繁忙的十字路口，转过围墙，一簇阳光从楼与树见散落，丁达尔告诉我们，光波的波长稍大于雾气微粒就会发生散射，微粒越接近光波长效应越明显。这就是我们小学二年级熟知的丁达尔效应。走过光柱，感受日光带来的温暖。

~~<img src=\"./images/没拍照片.jpg\"/>~~

## 「心脏」拼接

板子终于回来了，焊接的时候发现，立创的板子预热后有股清香，不知道是不是加了什么新材料，也有可能是我那低温锡膏的味道。曾经设想过很多，但从没实践过，希望能一切顺利吧~
我这个一拖再拖的性子回板都两三天了，还没焊接完。

~~不要问那个歪歪的大方块为啥歪，问就是画小了~~

{% image /headimg/weeknote/202449/1.jpg 第一条管道 %}

## 又是折腾

其实也不算折腾，搭建了一个MC服务器，内存着实有点不够用。需要用 Java17 才行，很久很久以前，用[树莓派4搭建过MC服务器](/2022/06/08/120705/)，现在还需要搞个内网穿刺公网才能访问。

{% image /headimg/weeknote/202449/1.png 客户端 %}

{% image /headimg/weeknote/202449/2.png 服务端 %}

{% image /headimg/weeknote/202449/3.png 挖树的性能 %}

