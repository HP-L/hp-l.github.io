---
title: WeekNote 2024-44
# cover: /now/notes.png
cover: /headimg/weeknote/202444_6.jpg
banner: /headimg/weeknote/202444_6.jpg
thumbnail: /headimg/weeknote/202444_6.jpg
index_img: /headimg/weeknote/202444_6.jpg
banner_img: /headimg/weeknote/202444_6.jpg
date: 2024-11-1 11:06:24
breadcrumb: true
published: true
nav_tabs: true # 这就意味着页面会显示首页文章导航栏
topic: WeekNote # 专栏 e-sth or mc or WeekNote
categories:
  - WeekNote
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine date:二〇二四年十月三十一日『第四十四周』 %}
<!-- line left -->
岁月当歌，人生几何。一生的时间对于浩瀚宇宙来说只是沧海一粟，珍惜当下，每一群伙伴，每一个眼神，每一个瞬间，每一道风景。一周一记，记录岁月流逝的痕迹。
{% endpaper %}
</p></div>

<div id="first_down"><p>

在众多包括但不限于我友链页面朋友的影响下，于 2024-10-28 决定开始记录周记，后续周记以年份 + 本年第 N 周为标题，可在专栏 topic 页面查看。


## 折腾小站

给小站重新调整了下导航、更新了[about](/about)，添加了些许页面。还为小站添加了一年四季！折腾最久的就是雪花飘落本地记录，存储在`localStorage`，这样刷新后就不会重置啦。（在页面左下角小太阳右边的就是啦，一年四季的图标都不一样），还练习了下好久没碰的调色。

{% image /headimg/weeknote/202444_6.jpg  一年四季 %}

{% image  /headimg/weeknote/202444_6.png 调色 %}

## 盆架子树

终于，它的花期过了。盆架树（Alstonia rostrata C. E. C. Fisch.）是夹竹桃科鸡骨常山属常绿乔木。花香极具穿透力，戴上口罩也于事无补。实在是受不了它的花香，每晚回家走过的每一条街道，都能闻到。每天回家路上头晕晕的{% emoji blobcat blobcatdead %}，我想大多数人都是这样吧。

{% image https://p9.itc.cn/images01/20210826/f8d77260d73a4633933c2f2b08c35b56.png  盆架子树 width:400px padding:16px %}

## {% mark Error color:error %}

快被这个 RK3288 的板子搞崩溃了啊啊。今年上半年从咸鱼淘来的小垃圾，性能平替树莓派3B-2G版本的小开发版。make install回车，然后 {% mark Error color:error %} {% mark Error color:error %}  还是 {% mark Error color:error %}  (╥﹏╥)，上一次这么痛苦的时候还是在上一次（其实忘了，属于是好了伤疤忘了疼），十几年前的芯片资料真的太少了，网上成品虽然能用，但 docker 无法部署，提示运行OCI失败，找不到设备`/dev/mqueue`，无法挂载，搜索好像说内核配置有问题。
{% image /headimg/weeknote/202444_2.png width:400px padding:16px %}

## 插座哭了

插座哭了，声音很大，突如其来，火光四溅，当时的我就背对着它。物业来看时说，可能是锡丝短接了插座，实在恐怖，试想如果没人看到，会不会引起火灾。
{% image /headimg/weeknote/202444_1.png width:400px padding:16px %}

## {% emoji blobcat blobcatgooglytrash %}

最近癫癫的，可能是看博弈论和经济学书籍的缘故吧，看到商店打特价就在想：嗯，这是一种价格歧视，社会福利上升，大家都付出了自己认为值得的成本；出地铁站时排队过刷卡机，又在想：长队伍通道不一定不好，人短队伍通道也许反而等你走到，开始排队的时候有，队伍可能比之前人多的队伍更多，随机选择可能得到个体利益最大化，整体最终达到一种纳什均衡...完了完了，大脑开始不听使唤了

## 老旧坏机拯救计划

手上的老手机又罢工了，拆开一查电池问题，换一个轻松点亮。换电池的时候索性全部拆开，看一看手机的五脏六腑，中间的图二就是主板，硅脂下面就是大脑（CPU）
{% gallery layout:grid ratio:square size:l %}
![我是图一](/headimg/weeknote/202444_3.jpg)
![我是图二](/headimg/weeknote/202444_4.jpg)
![我是图三](/headimg/weeknote/202444_5.jpg)
{% endgallery %}


</p></div>