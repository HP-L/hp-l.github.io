---
title: WeekNote 2024-51
cover: /now/notes.png
banner: /now/notes.png
thumbnail: /now/notes.png
index_img: /now/notes.png
banner_img: /now/notes.png
date: 2024-12-20 16:26:27
published: true
breadcrumb: true
nav_tabs: true # 这就意味着页面会显示首页文章导航栏
topic: WeekNote # 专栏 e-sth or mc or WeekNote
categories:
  - WeekNote
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine date:二〇二四年十二月二十日『第五十一周』 %}
<!-- line left -->
是忙忙碌碌的一周，工作占据了我大部分的日常，好在一切顺利，没有被高强度的工作拉跨。
{% endpaper %}
</p></div>

## 小记

每天都会路过一条街，两侧都是路边摊，浓郁的烧烤味和酱香味散布在整条街道。自从地摊经济开始发展，确实不在是冷冰冰的城市了，有了些许生活的气息。

小时候牵着父母的手，周围都是高大的黑色人影和冰冷的玻璃块，那时候不是很明白，就只是跟着走着。回想起那时候看到的，就像是《齐马蓝》里面的街道（可能是个头太小了或者是记忆模糊了吧）。

## Linux & macos

如今本地服务又重新上线了，项目管理和云盘存储以及 mc 服务器全部迁移完毕，mysql 由于没有导出数据库，如果要从系统文件中恢复，需要安装同版本然后搭建，懒得弄了，反正数据量不大，手动重新配置吧。

我开始由于，要继续使用 Linux 做服务器还是改用常用的 macOS 搭建，我选择 macOS，原因很简单，不想频繁切换系统，Linux 和 macOS 是安装在一台物理服务器上的。

相比之下 Linux 确实跑服务或者开发环境相对好一点点，但是软件生态很多厂家都没有适配 Linux 的软件，前几天看到微信竟然出了 Linux 版本，用起来感觉不错，大部分 pc 上的功能他都有，还能刷朋友圈。macOS 的话 ui 方面没得说，软件生态也不错，跑跑 apachectl 和 mysql 什么问题不大。其实有一点奇怪在于，Linux 下开 mc 服务器，CPU 占用率 40% 以上，但是 macOS 占用率就不是很高，可能是对内核分配的机制不太一样吧

{% image /headimg/weeknote/202451/1.png 活动监视器 %}

## 白泽号

上一版回来了，也测试了功能，整体单个差不多这样，两个上下搭起来， 然后是一个失误，开机键没接，还得飞线，下一版再改。

{% image /headimg/weeknote/202451/6.jpg pcba %}

最近在看机器学习和 NLP 相关的资料，按计划排因该到做 NLP 部分了，但是发现好些知识储备不足，还得学学。好在有些基础，曾经了解过机器视觉方面的东西，理解起来不是很难。最开始看 NLP 课程发现机器学习的部分知识已经忘记了，回头又去看吴恩达的机器学习课程。想从底层开始写，还是要学扎实点。

{% image /headimg/weeknote/202451/2.png 甘特图 %}

硬件第二版相对第一版更注重 layout 设计而不是原理部分，原理部分第一版已经调通了。

{% gallery layout:grid ratio:origin size:xl %}
![3D正面](/headimg/weeknote/202451/3.png)
![3D背面](/headimg/weeknote/202451/4.png)
{% endgallery %}

这版呢，升级了一下，苦于信号质量和层数之间的选择，用了 6 层板。脑袋部分嘛，用独立电源设计，外设有外设的电源，这样能减小体积，也能将核心单独从整体中抽离出来成为小型机器人。背面预留了一个小借口，和外部 MCU 通讯，通过 MCU 上连接的外部传感器感受世界。结构正在构建中，还没形成具体形态。

{% image /headimg/weeknote/202451/5.png layout %}

