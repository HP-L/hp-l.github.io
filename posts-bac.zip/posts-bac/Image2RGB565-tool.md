---
title: Image转RGB565工具
cover: /headimg/headimg/headimg_34.png
banner: /headimg/headimg/headimg_34.png
thumbnail: /headimg/headimg/headimg_34.png
index_img: /headimg/headimg/headimg_34.png
banner_img: /headimg/headimg/headimg_34.png
poster:
  topic: null
  headline: null
  caption: null
  color: null
tags:
  - RGB565
categories:
  - 工具
date: 2024-07-09 11:55:44
topic:
---

# 写在前面

一个小工具


<style>
/* 样式用于将标签样式化为按钮 */
.custom-button {
  display: inline-block;
  padding: 10px 20px;
  font-size: 16px;
  font-weight: bold;
  color: #fff;
  background-color: #007bff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

/* 隐藏文件选择输入框 */
.input-file {
  display: none;
}
</style>

<script>
    // Dither threshold values for each color channel
    const ditherThresholdR = [
      0, 8, 2, 10,
      12, 4, 14, 6,
      3, 11, 1, 9,
      15, 7, 13, 5
    ];

    const ditherThresholdG = [
      0, 8, 2, 10,
      12, 4, 14, 6,
      3, 11, 1, 9,
      15, 7, 13, 5
    ];

    const ditherThresholdB = [
      0, 8, 2, 10,
      12, 4, 14, 6,
      3, 11, 1, 9,
      15, 7, 13, 5
    ];


    // Returns the nearest color value
    function getClosestColorValue(colorValue) {
      return (colorValue >> 2 << 2);
    }



    /**
     * 对图像数据应用抖动算法
     *
     * @param {Uint8ClampedArray} imageData - 包含图像数据的数组，每个像素为 RGBA 格式
     * @param {number} width - 图像的宽度
     * @param {number} height - 图像的高度
     * @return {Uint8ClampedArray} - 处理后的图像数据数组
     */

    function dither(imageData, width, height) {
      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
          const pixelIndex = (y * width + x) * 4;
          let r = imageData[pixelIndex];
          let g = imageData[pixelIndex + 1];
          let b = imageData[pixelIndex + 2];

          // 获取此像素的抖动阈值索引
          const thresholdIndex = ((y & 3) << 2) + (x & 3);

          // 将抖动算法应用于每个颜色通道
          r = getClosestColorValue(Math.min(r + ditherThresholdR[thresholdIndex], 255));
          g = getClosestColorValue(Math.min(g + ditherThresholdG[thresholdIndex], 255));
          b = getClosestColorValue(Math.min(b + ditherThresholdB[thresholdIndex], 255));

          // 更新 imageData 数组中的像素数据
          imageData[pixelIndex] = r;
          imageData[pixelIndex + 1] = g;
          imageData[pixelIndex + 2] = b;
        }
      }

      return imageData;
    }

    function handleFileSelect_dither(event) {
      console.log("handleFileSelect_dither");
      var file = event.target.files[0];

      if (!file) {
        alert('Please select an image file.');
        return;
      }

      var reader = new FileReader();
      reader.onload = function (event) {
        var img = new Image();
        img.onload = function () {
          var canvas = document.createElement('canvas');
          var ctx = canvas.getContext('2d');
          canvas.width = img.width;
          canvas.height = img.height;
          ctx.drawImage(img, 0, 0);

          var imageData = ctx.getImageData(0, 0, img.width, img.height);
          var data = imageData.data;
          
          data_B = dither(data, img.width,img.height);

          var rgb565Array = [];

          for (var i = 0; i < data_B.length; i += 4) {
            var r = data_B[i];
            var g = data_B[i + 1];
            var b = data_B[i + 2];

            // Convert RGB888 to RGB565
            var r5 = (r >> 3) & 0x1F;
            var g6 = (g >> 2) & 0x3F;
            var b5 = (b >> 3) & 0x1F;

            var rgb565 = (r5 << 11) | (g6 << 5) | b5;
            rgb565Array.push(rgb565);
          }

          var width = img.width;
          var height = img.height;

          // var rgb565Array_B = [];


          // Generate C array output
          var cArray = 'const uint16_t image[' + height + '][' + width + '] = {\n';
          for (var row = 0; row < height; row++) {
            cArray += '  {';
            for (var col = 0; col < width; col++) {
              var index = row * width + col;
              cArray += '0x' + rgb565Array[index].toString(16);
              if (col < width - 1) {
                cArray += ', ';
              }
            }
            cArray += '}';
            if (row < height - 1) {
              cArray += ',\n';
            } else {
              cArray += '\n';
            }
          }
          cArray += '};';

          // Save to text file
          var blob = new Blob([cArray], {
            type: 'text/plain'
          });
          var url = URL.createObjectURL(blob);
          var a = document.createElement('a');
          a.href = url;
          a.download = 'image_data.c';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        };

        img.src = event.target.result;
      };

      reader.readAsDataURL(file);
    }

    function handleFileSelect_no_dither(event) {
      console.log("handleFileSelect_no_dither");
      var file = event.target.files[0];

      if (!file) {
        alert('Please select an image file.');
        return;
      }

      var reader = new FileReader();
      reader.onload = function (event) {
        var img = new Image();
        img.onload = function () {
          var canvas = document.createElement('canvas');
          var ctx = canvas.getContext('2d');
          canvas.width = img.width;
          canvas.height = img.height;
          ctx.drawImage(img, 0, 0);

          var imageData = ctx.getImageData(0, 0, img.width, img.height);
          var data = imageData.data;
          
          data_B = data;

          var rgb565Array = [];

          for (var i = 0; i < data_B.length; i += 4) {
            var r = data_B[i];
            var g = data_B[i + 1];
            var b = data_B[i + 2];

            // Convert RGB888 to RGB565
            var r5 = (r >> 3) & 0x1F;
            var g6 = (g >> 2) & 0x3F;
            var b5 = (b >> 3) & 0x1F;

            var rgb565 = (r5 << 11) | (g6 << 5) | b5;
            rgb565Array.push(rgb565);
          }

          var width = img.width;
          var height = img.height;

          // var rgb565Array_B = [];


          // Generate C array output
          var cArray = 'const uint16_t image[' + height + '][' + width + '] = {\n';
          for (var row = 0; row < height; row++) {
            cArray += '  {';
            for (var col = 0; col < width; col++) {
              var index = row * width + col;
              cArray += '0x' + rgb565Array[index].toString(16);
              if (col < width - 1) {
                cArray += ', ';
              }
            }
            cArray += '}';
            if (row < height - 1) {
              cArray += ',\n';
            } else {
              cArray += '\n';
            }
          }
          cArray += '};';

          // Save to text file
          var blob = new Blob([cArray], {
            type: 'text/plain'
          });
          var url = URL.createObjectURL(blob);
          var a = document.createElement('a');
          a.href = url;
          a.download = 'image_data.c';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        };

        img.src = event.target.result;
      };

      reader.readAsDataURL(file);
    }
</script>
  <!-- 使用label来包裹input -->
  <label for="fileInput_dither" class="custom-button">Choose File(带有抖动)</label>
  <input type="file" id="fileInput_dither" class="input-file" accept="image/*" onchange="handleFileSelect_dither(event)">

  <label for="fileInput_no_dither" class="custom-button">Choose File</label>
  <input type="file" id="fileInput_no_dither" class="input-file" accept="image/*" onchange="handleFileSelect_no_dither(event)">

<!-- 
Category：

理论：理论知识技能，技术
应用：应用笔记，实操
折腾：折腾折腾折腾折腾！(其实属于应用，但就是玩！)
方法：方法论（经验谈），如工程方法
工具：针对具体工具的介绍、使用方法、分析适用场景等；使用工具如何如何解决具体问题，应该放在「应用」里
作品：自己的作品（成品）、个人项目日志等
杂谈：生活碎碎念
自然科学：物理，化学，数学
其他：没法分类的东西

Tags

细分领域：机器之脉络(硬件),机器之魂魄(嵌入式软件,机器学习，算法等),机器之骨骼(结构),
形式：日志
具体内容：个人作品、方法论、随笔
语言：python C C# Java Html micropython 微信小程序
IDE：Arduino CUBEIDE Vscode
自然科学：代数 几何 概率 黑洞 白矮星 四维空间...
IC OR IDE : STM32 ESP32 ESP8266 C51 树莓派 RK3399 野火开发版 MIQI
模组：ws2812b
系统：Linux Windows macOS openwrt Docker   termux
游戏：MC
博客：hexo 主题 魔改
折腾系类：黑苹果，整服务器，termux

 -->


