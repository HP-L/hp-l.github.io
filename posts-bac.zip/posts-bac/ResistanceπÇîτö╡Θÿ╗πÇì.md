---
title: Resistance「电阻」
cover: /headimg/headimg/headimg_15.jpg
banner: /headimg/headimg/headimg_15.jpg
thumbnail: /headimg/headimg/headimg_15.jpg
index_img: /headimg/headimg/headimg_15.jpg
banner_img: /headimg/headimg/headimg_15.jpg
poster:
  topic: null
  headline: null
  caption: null
  color: null
tags:
  - 机器之脉络
  - 元器件之旅
  - 电阻
categories:
  - 工具
published: true
date: 2024-11-06 08:28:11
topic: e-sth
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine date:二〇二四年十一月六日 %}
<!-- line left -->
电阻，在物理学中表示导体对电流阻碍作用的大小。一块PC主板上有大大小小的电阻，电阻类别很多，像PC主板上最常见的是碳膜贴片电阻，厂家国内有厚膜等。了解电阻先从电阻数据手册开始。
{% endpaper %}
</p></div>

## 数据手册部分解读

### 命名规则

{% image 1.png  命名规则 download:1.png %}

上图直观描述了电阻厂商对电阻的命名规则，将常见的特性参数直观表示出来

- 封装（Product Type）指的是贴片电阻大小，需要根据PCB大小、摆放空间考虑；
- 功率（Wattage），硬件设计需要考虑功率大小，这颗小小的电阻会将电能转化成热能，当他承受不住热量时，就会烧断。但功率并非一成不变，后面会有说明。
  $$P = I^{2}R$$
- 精度（Tolerance），器件制造时会有误差，这个就表示阻值范围
- 阻值（Resistance Value），阻值大小，计数方式有不同，但相应规格书会有标明。
- 包装方式（Packing Type），有卷装料（Tape  Reel）、散装（Bulk）、管装（Tube）、托盤包装（Tray）
- 单包总数（Packing quantity）

### 降额曲线

{% image 2.png  降额曲线 download:2.png %}

在温度不断增高的过程中，需要限制功率以保证电阻不被烧坏。

### 内部构造

{% image 3.png  内部构造 download:3.png %}

High purity Alumina substrate：高纯氧化铝基板

Protective coating：保护性涂层

Resistance element：电阻元件

4、5、6为接线段材料

## 原理

电阻是一个物理量，用于衡量导体对电流阻碍作用的大小。

{% folding open:false 形象一点 %}
{% image 4.png  内部构造 download:4.png %}
{% endfolding %}

## 0欧姆电阻

曾经拆过一个遥控器，见到过有一个电阻上标志着`000`，这种就是0欧姆电阻，一般做跳线使用，像遥控器这类单层板只能在一面制作线路，线路交叉时就会用上跳线。

{% image 5.png 0欧姆电阻 download:5.png %}

## 常用类别

就消费类电子而言，看到网上的一些拆解以及自己手上拆的一些pcb，常用有下面几种：

> 1. 碳膜电阻
>     - 适用于一些对功率要求不高的电路
>     - 温度系数相对较大
>     - 长期稳定性相对较差
>     - ---
>     - 作为限流、分压等基本功能的电阻元件。

> 2. 金属膜电阻
>     - 适用于对电阻精度和稳定性要求较高的场景
>     - 精度较高，温度系数低，温度稳定性好，噪声也比较低
>     - 长期稳定性相对好
>     - ---
>     - 电源管理电路、信号处理电路等中使用，一些测量电量的电阻就是这种精密电阻

> 3. 金属氧化物膜电阻
>     - 适用于低精度场景（比碳膜电阻低）
>     - 抗氧化性更强，耐压耐热
>     - 长期稳定性相对好
>     - ---
>     - 电源管理电路、信号处理电路等中使用，一些测量电量的电阻就是这种精密电阻

> 4. 厚膜电阻
>     - 适用于低精度场景（ 5% 或 10% 左右）
>     - 成本相对较低，阻值范围宽
>     - 应用最广泛
>     - ---
>     - 哪哪都有

## 应用案例

> 这里讲解开漏（开集：三极管）电路

这是I2C电路结构图

{% image 6.png I2C电路结构 download:6.png %}

对于N-MOS，$V_{GS} > V_t$则导通拉低。上面可以看到总线上所有的MOSFET导通时接地，MOSFET关断时，若无上拉电阻则为悬浮状态，而I2C是二进制数字信号，只有电压高于特定值时才能识别为数字`1`。


<!-- ## _还没写完.._ -->


<div id="first_down"><p>
{% paper style:underline title:<<<文末闲语>>> author:Phosphine %}
<!-- line left -->
又水了一篇文章，电阻部分确实比较简单，应用很广，不同行业对电阻的要求不一样，其要求主要体现在材料上，材料不同决定了寿命，适用环境等。再就是0欧姆电阻也比较常用。
{% endpaper %}
</p></div>


<!-- 
Category：

理论：理论知识技能，技术
应用：应用笔记，实操
折腾：折腾折腾折腾折腾！(其实属于应用，但就是玩！)
方法：方法论（经验谈），如工程方法
工具：针对具体工具的介绍、使用方法、分析适用场景等；使用工具如何如何解决具体问题，应该放在「应用」里
作品：自己的作品（成品）、个人项目日志等
杂谈：生活碎碎念
自然科学：物理，化学，数学
其他：没法分类的东西

Tags

细分领域：机器之脉络(硬件),机器之魂魄(嵌入式软件,机器学习，算法等),机器之骨骼(结构),
形式：日志
具体内容：个人作品、方法论、随笔
语言：python C C# Java Html micropython 微信小程序
IDE：Arduino CUBEIDE Vscode
自然科学：代数 几何 概率 黑洞 白矮星 四维空间...
IC OR IDE : STM32 ESP32 ESP8266 C51 树莓派 RK3399 野火开发版 MIQI
模组：ws2812b
系统：Linux Windows macOS openwrt Docker   termux
游戏：MC
博客：hexo 主题 魔改
折腾系类：黑苹果，整服务器，termux

 -->


