---
title: 注册机出现cannot retrieve MAC addre
cover: /headimg/headimg/headimg_35.png
banner: /headimg/headimg/headimg_35.png
thumbnail: /headimg/headimg/headimg_35.png
index_img: /headimg/headimg/headimg_35.png
banner_img: /headimg/headimg/headimg_35.png
poster:
  topic: null
  headline: null
  caption: null
  color: null
tags:
  - 注册机
  - 破解
  - mac地址
categories:
  - 工具
date: 2024-07-28 09:08:28
topic:
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine %}
<!-- line left -->
Keyshot注册机破解时出现`cannot retrieve MAC addre`，网上搜了一圈设置MAC地址的办法都无法解决。添加成功设备管理器的网卡设置已经出现MAC地址了也还是不行。
{% endpaper %}
</p></div>

手上一台win11 pc安装keyshot时出现`cannot retrieve MAC addre`，用手机有线提供以太网则不会出现问题，最终解决办法如下：

1. `win` + `R` 输入 `hdwwiz` 
2. 点击下一步直到出现{% mark 安装我手动从列表选择的的硬件(高级) color:red %}
，找到{% mark 网络适配器 color:red %}
3. 左侧厂商选择{% mark Microsoft color:red %}，右侧型号选择{% mark Microsoft_KM-TEST环回适配器 color:red %}
4. 开始安装。重新破解成功不会出现报错

上网搜了一下这个Microsoft_KM-TEST环回适配器，AI 给出了答案

> Microsoft_KM-TEST环回适配器的作用
> Microsoft_KM-TEST环回适配器（Loopback Adapter）是一种虚拟网络适配器，主要用于在计算机系统中模拟网络连接。它的作用是使计算机可以与自身进行通信，而无需实际的物理网络连接。环回适配器通常用于以下场景：
> - 网络应用程序测试：通过将网络应用程序配置为使用环回适配器作为目标地址，可以在没有真实网络连接的情况下测试和调试应用程序的功能和性能。
> - 网络配置测试：使用环回适配器具于测试网络配置，确保计算机的网络配置正确无误。
> - 软件开发和测试：在开发和测试软件时，环回适配器可以模拟网络环境，帮助开发者在没有真实网络设备的情况下进行测试。
> - 网络安全：环回适配器可以用于测试和评估计算机的安全性，例如模拟攻击、漏洞扫描等。
> - 虚拟化环境：在虚拟化环境中，环回适配器可以用作虚拟机之间或虚拟机与物理机之间的内部通信通道，使得虚拟机能够通过该适配器进行内部网络通信，而无需物理网卡的支持。
> - 网络故障排除：环回适配器也可以在本地计算机上用于诊断和排除网络问题。通过将网络流量通过环回适配器进行循环发送和接收，可以检查网络配置、路由、防火墙设置等是否正常工作. 

<!-- <div id="first_down"><p>
{% paper style:underline title:<<<文末闲语>>> author:Phosphine %}
<!-- line left -->
没有文末闲语
{% endpaper %}
</p></div> -->

<!-- ## _还没写完.._ -->

<!-- 
Category：

理论：理论知识技能，技术
应用：应用笔记，实操
折腾：折腾折腾折腾折腾！(其实属于应用，但就是玩！)
方法：方法论（经验谈），如工程方法
工具：针对具体工具的介绍、使用方法、分析适用场景等；使用工具如何如何解决具体问题，应该放在「应用」里
作品：自己的作品（成品）、个人项目日志等
杂谈：生活碎碎念
自然科学：物理，化学，数学
其他：没法分类的东西

Tags

细分领域：机器之脉络(硬件),机器之魂魄(嵌入式软件,机器学习，算法等),机器之骨骼(结构),
形式：日志
具体内容：个人作品、方法论、随笔
语言：python C C# Java Html micropython 微信小程序
IDE：Arduino CUBEIDE Vscode
自然科学：代数 几何 概率 黑洞 白矮星 四维空间...
IC OR IDE : STM32 ESP32 ESP8266 C51 树莓派 RK3399 野火开发版 MIQI
模组：ws2812b
系统：Linux Windows macOS openwrt Docker   termux
游戏：MC
博客：hexo 主题 魔改
折腾系类：黑苹果，整服务器，termux

 -->


