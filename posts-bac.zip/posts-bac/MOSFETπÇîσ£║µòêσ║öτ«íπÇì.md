---
title: MOSFET「场效应管」
cover: /headimg/deemo/crankyanotherkatharsis.png
banner: /headimg/deemo/crankyanotherkatharsis.png
thumbnail: /headimg/deemo/crankyanotherkatharsis.png
index_img: /headimg/deemo/crankyanotherkatharsis.png
banner_img: /headimg/deemo/crankyanotherkatharsis.png
poster:
  topic: null
  headline: null
  caption: null
  color: null
tags:
  - 机器之脉络
  - 元器件之旅
categories:
  - 理论
published: true
date: 2024-11-18 10:35:46
topic: e-sth
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine date:二〇二四年十一月十五日 %}
<!-- line left -->
之前有写过[三极管和MOS管对比](/2022/06/01/132405/)，不是很详细，本篇细聊MOSFET。本文按照「规格书解读->选型->工作原理讲解->等效电路->量子领域应用」来写。
{% endpaper %}
</p></div>

## 数据手册部分解读

> 此规格书为**功率N−CHANNELMOSFET**手册。
> 如需查看原文档，打开商城后点击下载数据手册即可
> https://item.szlcsc.com/527928.html

### MAXIMUM RATINGS（最大额定值）

{% image 1.png  最大额定值 download:1.png %}

- Drain−to−Source Voltage「$V_{DSS}$」：漏源极间的耐压，DS电压偶尔超过VDSS，MOSFET会进入雪崩击穿区（后面会提到），可能不会马上损坏MOSFET，但是经常超过的话会使MOSFET性能下降或者损坏。

- Gate−to−Source Voltage「$V_{GS}$」：场效应管能够承受的最大栅极-源极电压

- Continuous Drain「$I_D$」：场效应管能够承受的最大漏极电流。

- Power Dissipation「$P_D$」：功率耗散

-  Operating Junction and Storage Temperature「$T_J$, $T_{STG}$」：如果确保器件工作在这个温度区间内，将极大地延长其工作寿命。

- Source Current (Body Diode)「$I_{DM}$」：源极电流 （体二极管）

- Single Pulse Drain−to−Source Avalanche Energy (IL(pk) = 5 A)「EAS」：雪崩能量
> 参考文档：[Avalanche Energy (EAS) caluculation of Power MOSFET.pdf](https://toshiba.semicon-storage.com/info/application_note_en_20200306_AKX00083.pdf?did=68907)

- Lead Temperature for Soldering Purposes「$T_L$」：用于焊接的引线温度

> 为什么$I_D$和$P_D$分别会有两个参数？
> 注意$R_{\theta JC}$（这是结壳间的热阻）和$R_{\theta JA}$（表示结与环境间的热阻）
> - $R_{\theta JA}$和$R_{\theta JA}$的关系：当功率晶体管的散热片足够大而且接触足够良好时$R_{JC} = 0$有$R_{JA}=R_{JC}+R_{CA}=R_{JC}+0$，可以认为封装壳温Tc=Ta(环境温度)，晶体管外壳与环境间的热阻。
> {% image 2.png  两种环境 download:2.png %}
> 这两种环境下对应的功率也就不同。
> > 热阻计算公式
> > $$T_a=T_j-P(R_{jc}+R_{cs}+R_{sa})=T_j-P*R_{ja}$$
> > - $Ta$表示环境温度
> > - $Tj$表示晶体管的结温
> > - $P$表示功耗
> > - $R_{jc}$表示结壳间的热阻
> > - $R_{cs}$表示晶体管外壳与散热器间的热阻
> > - $R_{sa}$表示散热器与环境间的热阻
> > - $R_{ja}$表示结与环境间的热阻。
> > 
> > 例如：壳温Tc=25℃时的最大允许功耗是1.5W，Rjc是83.3度/W
> > 代入公式$T_c=T_j- P*R_{jc}$有：$25=T_j-1.5*83.3$得：$T_{j}=150$一般芯片最大允许结温是确定的。

### ICON

{% image 3.png  ICON download:3.png %}

**如何记忆增强型和耗尽型？**
增强型：（关闭得**更**彻底）源极和漏极之间不存在导电沟道，器件处于截止状态。「可看到S和D的竖线**断开了**」
耗尽型：（关闭得**不**彻底）栅极电压为零，源极和漏极之间也能导通一定的电流。「可看到S和D的竖线**有连接**」

### ELECTRICAL CHARACTERISTICS「电气特性」

#### 导通和关断特性

{% image 4.png  ON/OFF--CHARACTERISTICS download:4.png %}

- **Drain−to−Source Breakdown Voltage**「$V_{(BR)DSS}$」：漏源击穿电压
- Zero Gate Voltage Drain Current「$I_{DSS}$」:零栅极电压漏极电流
- Gate−to−Source Leakage Current「$I_{GSS}$」：栅极到源极漏电流

- **Gate Threshold Voltage**「$V_{GS(TH)}$」：栅极阈值电压
- Drain−to−Source On Resistance「$R_{DS(on)}$」：漏极至源极导通电阻

#### CHARGES, CAPACITANCES & GATE RESISTANCE「电荷、电容和栅极电阻」

{% image 5.png CHARGES,CAPACITANCES&GATE-RESISTANCE download:5.png %}

- $C_{ISS}$和$C_{OSS}$
影响MOSFET开关时间, $C_{ISS}$越大, 开通及关断时间就越慢(开关损耗越大)。

> 还记得电容可以做延时吗，这里可以简单理解为打开MOSFET时，经过了一段时间电压逐步上升达到了门限电压，开关才被打开。

慢的开关速度带来较好的EMI特性。Cgd会影响漏极有异常高电压时，传到栅极电压能量的大小，会对雷击测试项目有一定影响。

无论是$C_{ISS}$、$C_{OSS}$、$C_{rss}$中的哪一个，我们都希望他们尽量小一些。后面原理部分会做解释。

#### SWITCHING CHARACTERISTICS「开关特性」

{% image 7.png  SWITCHING-CHARACTERISTICS download:7.png %}

- Turn−On Delay Time「$t_{d(ON)}$」：（开启延迟时间）
- Rise Time「t_r」：上升时间
- Turn−Off Delay Time「$t_{d(OFF)}$」：（关闭延迟时间）
- Fall Time「t_f」：下降时间

#### DRAIN−SOURCE DIODE CHARACTERISTICS「漏源二极管特性」

{% image 8.png  DRAIN−SOURCE-DIODE-CHARACTERISTICS download:8.png %}

- Forward Diode Voltage「$V_{SD}$」：正向二极管电压
- Reverse Recovery Time「$t_{rR}$」：反向恢复时间
- Charge Time「$t_{a}$」：充电时间
- Discharge Time「$t_{b}$」：放点时间
- Reverse Recovery Charge「Q_{RR}」：反向恢复电荷

对于DCDC中，十分看重时间，恢复上升下降时间越短的越好。

### 选型

{% image 23.png  选型 download:23.png %}

## 工作原理讲解

### 内部构造

{% image 14.png  MOSFET构造 download:14.png %}

> 为什么叫做N-Channel？
> 因为沟道是**由N型半导体**组成，上图可以看到左侧N型MOSFET中**两个N型**半导体之间将会在**G极的作用下形成沟道**，N型半导体将会相连接而导通，由于需要形成N型沟道，则需要对电子吸引，因此在G极施加电压后吸引电子（N型半导体的多数载流子）形成N沟道导通N型半导体。
> 简言之：**G极施加正电压吸引电子形成N沟道连接了N型半导体导通了N型MOSFET**。
> 同理可得：**G极施加负电压吸引空穴形成P沟道连接了P型半导体导通了P型MOSFET**。
> 
> ---
> 
> *Tips：空穴相对于电子而言抽象出来的概念，元素周围会有稳定的电子，而缺失了电子的位置称为空穴，想具体可以搜索PN结*


> 电流流向（简单理解的方法）
> 看寄生二极管，与其电流方向相反（与PN结方向相反），电流必须从N型半导体流向P型半导体，才能达到阻碍电流达到开关的效果。不论哪种MOSFET，都必须遵循，因此N型半导体必须施加正电压。

> 为什么衬底要和S极相连？
> 将衬底与源极相连接，两者的**电位就相同**了，没有正向压降，两者间的PN结就不会导通，从而就**不会有电流流过PN结**。

#### 实际物理结构

{% image 15.png  实际物理结构 download:15.png %}

#### 光刻

{% image 16.png  光刻 download:16.png %}

现代CMOS工艺

{% image 17.png  现代CMOS工艺 download:17.png %}

#### 齐纳二极管等效电路（Zener diode equivalent）

{% image 9.png  MOSFET-cross-section-and-Zener-diode-equivalent download:9.png %}

当在板安装等过程中对栅极施加静电时，栅极氧化物可能会被破坏，在这种情况下，有一种方法是通过在栅极和源极端子之间插入 ESD 保护二极管来保护 MOSFET，一些产品采用这种措施，它在短时间内吸收较大的过电压（**浪涌**），并工作，以便不会对其他半导体产品施加超过一定电压的电压。

#### 体二极管

从结构层面看，左侧标识的电流$I_D$就是体二极管电流路径

{% image 12.png  结构层面 download:12.png %}

右侧的Body Diode就是体二极管

{% image 10.png  体二极管 download:10.png %}

体二极管的反向恢复时间产生原因：少数载流子反向恢复
> 由于二极管处于导电状态，少数载流子返回原来的区域或复合，寄生电容中积聚的电荷发生放电，电流减小至零，进一步变为负值。这种反向电流称为反向恢复电流。

{% image 11.png 少数载流子反向恢复 download:11.png %}

#### 分布电容

> **为什么内部分部电容如此重要？**
> DCDC高速开关时，需要高速切换状态，此时切换延时就十分重要了。

- 输入电容(lnput  Capacitance)：$C_{iss}=C_{gd}+C_{gs}$
- 输出电容(Output Capacitance)：$C_{oss}=C_{gd}+C_{ds}$
- 逆导电容( Reverse Transfer  Capacitance)：$C_{rss}=C_{gd}$

> $C_{oss}$对于软开关的应用，Coss非常重要，因为它可能引起电路的谐振。
>
> $C_{iss}$输入功率组件驱动能力或损失时的参数。
>
> $C_{rss}$对于高频切换动作最有不良影响. 为了提高组件高频特性, $C_{gd}$要愈低愈好。

等效电路：

{% image 6.png  分布电容 download:6.png %}

#### 雪崩电压

电路中存在杂散的**电感**，由于电感存在，MOSFET关断时电流不会立刻变为0，而是继续流动，此时会产生感应电动势使得电压$V_{DS}$上升，有可能会上升到甚至超过$V_{DSS}$

> 想象一下，MOSFET关断后，电流持续流动撞击漏极（Drain），电子撞击强度过大就将撞坏MOSFET，导致雪崩击穿。

{% image 13.png  等效电路+雪崩电压 download:13.png %}

#### SOA(安全工作区) 

{% image 22.png  SOA download:22.png %}

图表中所示为在汲极电流ID和汲极－源极间电压VDSS的关系中，对于额定电压/电流、额定功率（发热）来说安全的、即不至于损害可靠性、不至于损坏的范围。

1. $R_{DS(ON)}$极限$V_{DS}/I_D$
1. 极限电流$I_{DM}$
1. 最大功率$P_{DM}=V_{DS}*I_D$
1. $B_{VDSS}$极限

## *题外话：量子隧穿*

### 半导体能级

{% image 18.png  半导体能级 download:18.png %}

从未观察层面讲能级是不连续的

### 隧道二极管(TD)

{% image 21.png  隧道二极管 download:21.png %}

江崎发现了反常的电流一电压特性。常见的二极管是没有中间的尖峰的，电流随电压增大而增大。如下图等电压达到（图B）时，电子发生隧穿，电流急剧增大。
当电压超过能使得电子隧穿的能级时（图C），电子无法隧穿，电流下降。
当电压上升到电子足够跃迁到上一个能级时（图d），大于这个能量状态的电子脱离了材料中单个原子的束缚，是可以在电场的作用下在材料中移动的，电流增加。

{% image 20.png  隧道二极管 download:20.png %}

> Ec是导带，是这个电子系统中比较高的一种能量状态，大于等于这个能量状态的电子脱离了材料中单个原子的束缚，是可以在电场的作用下在材料中移动的。所以叫导带。
> Ev是价带，是这个能量系统中比较低的能量状态，小于或等于这个能量状态的电子是被某个原子束缚住的，是形成了价键的。所以叫价带。
> Ef是费米能级，是这个电子系统的化学势，体现了电子系统活跃性，某种程度上可以说能体现系统的总能量。（自由电子的能量越高和自由电子总数目越大化学势越大）。

### 应用（隧道二极管振荡器）

> 隧道二极管用于不同的振荡器，如弛豫、微波等。它用作具有非常高速度的开关器件。用作逻辑存储器存储设备。用作微波振荡器高频这个二极管用作振荡器，放大器和开关它用作高频组件它用作存储逻辑存储器的存储设备它被使用在 FM 接收器和振荡器电路中，因为它是一种低电流设备因此，这是关于隧道二极管、结构、工作、优点、缺点及其应用的概述。 这些二极管用作振荡器、放大器、开关等。由于其快速响应，该二极管可以用作高频组件，但是，由于更好的设备的可访问性，因此未选择它。

### CMOS工艺中的量子隧穿

由于PN结间间隙非常窄，同时想CPU等集成电路输入电压极低，必须考虑量子隧穿效应，当能级接近时，电子会发生隧穿，导致电流增大，此时无法精确控制0和1了。

<!-- ## _还没写完.._ -->

<div id="first_down"><p>
{% paper style:underline title:<<<文末闲语>>> author:Phosphine %}
<!-- line left -->
简简单单的MOSFET其实远不止于此，文章仅仅讲述了功率MOSFET部分，这也是电源部分必修课，但大同小异，基本原理也逃不开这一套下来。以前只是听说量子隧穿，但不知道是什么，写文章的时候查了不少资料，量子领域的东西真是不简单。
{% endpaper %}
</p></div>


> 参考链接：
> 1. [第二课：如何理解功率MOSFET规格书「知乎」](https://zhuanlan.zhihu.com/p/646729442)
> 1. [技术文章: MOSFET规格书解读与参数详解.pdf](https://staging2.viitorsemi.com/wp-content/uploads/AN-005_CN.pdf)
> 1. [MOSFET | 如何看懂MOSFET手册？①「CSDN」](https://blog.csdn.net/chenhuanqiangnihao/article/details/112602538)
> 1. [半导体热阻问题深度解析(Tc,Ta,Tj,Pc)「新浪博客」](https://blog.sina.com.cn/s/blog_710b9b8a0100wn9n.html)
> 1. [一文看懂功率MOS管的每一个参数！)「立创商城」](https://www.szlcsc.com/info/12094.html)
> 1. [What are the characteristics of MOSFET body diodes?](https://toshiba.semicon-storage.com/us/semiconductor/knowledge/faq/mosfet/electrical-characteristics-of-mosfetsbody-diode-idr-idrp-vdsf-tr.html)
> 1. [结电容Cgd、Cgs、Cds与分布参数Ciss、Crss、Coss](https://www.eda365.com/thread-353562-1-1.html)
> 1. [MOS is sensitive to static electricity. How do you protect MOSFETs from static electricity?](https://toshiba.semicon-storage.com/ap-en/semiconductor/knowledge/faq/mosfet/mos-is-sensitive-to-static-electricityhow-do-you-protect-mosfets.html)
> 1. [什么是二极管反向恢复时间（$t_{rr}$）？](https://toshiba-semicon-storage.com/cn/semiconductor/knowledge/faq/diode/what-is-trr.html)
> 1. [mosfet电路图中的反向二极管什么作用？就是圈里面的二极管，体二极管是什么？「知乎」](https://www.zhihu.com/question/67214844)
> 1. [MOSFET中的雪崩是什么?（雪崩能力）](https://toshiba-semicon-storage.com/cn/semiconductor/knowledge/faq/mosfet/what-is-avalanche-capability.html)
> 1. [【PMOS/NMOS区别】从原理上区分记忆(含制程工艺知识)「知乎」](https://zhuanlan.zhihu.com/p/540653641)
> 1. [数电中N沟道增强型MOS管为防止有电流从衬底流向流向源极和导电沟道，通常将衬底与源极相连接「百度知道」](https://zhidao.baidu.com/question/491759966.html)
> 1. [CMOS工艺及版图](https://sfzx.yangtzeu.edu.cn/__local/E/EA/10/23C66E769BC2B254B8558BA4E0C_B657E825_4286AC.pdf?e=.pdf)
> 1. [量子隧穿「王一博，卜逸舟，曹颖康」](https://faculty.pku.edu.cn/_tsf/00/14/nmAJNvJBNfUj.pdf)
> 1. [半导体中的Ec, Ev,Ef之间是什么关系？「知乎问答回答一」](https://www.zhihu.com/question/295026477)
> 1. [什么是隧道二极管：工作原理及其应用](https://zh-cn.fmuser.net/content/?21143.html)


<!-- 
Category：

理论：理论知识技能，技术
应用：应用笔记，实操
折腾：折腾折腾折腾折腾！(其实属于应用，但就是玩！)
方法：方法论（经验谈），如工程方法
工具：针对具体工具的介绍、使用方法、分析适用场景等；使用工具如何如何解决具体问题，应该放在「应用」里
作品：自己的作品（成品）、个人项目日志等
杂谈：生活碎碎念
自然科学：物理，化学，数学
其他：没法分类的东西

Tags

细分领域：机器之脉络(硬件),机器之魂魄(嵌入式软件,机器学习，算法等),机器之骨骼(结构),
形式：日志
具体内容：个人作品、方法论、随笔
语言：python C C# Java Html micropython 微信小程序
IDE：Arduino CUBEIDE Vscode
自然科学：代数 几何 概率 黑洞 白矮星 四维空间...
IC OR IDE : STM32 ESP32 ESP8266 C51 树莓派 RK3399 野火开发版 MIQI
模组：ws2812b
系统：Linux Windows macOS openwrt Docker   termux
游戏：MC
博客：hexo 主题 魔改
折腾系类：黑苹果，整服务器，termux

 -->


