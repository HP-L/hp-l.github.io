---
title: kindle 越狱+插件安装
cover: /headimg/headimg/headimg_33.png
banner: /headimg/headimg/headimg_33.png
thumbnail: /headimg/headimg/headimg_33.png
index_img: /headimg/headimg/headimg_33.png
banner_img: /headimg/headimg/headimg_33.png
poster:
  topic: null
  headline: null
  caption: null
  color: null
tags:
  - kindle
categories:
  - 折腾
date: 2024-07-10 14:35:51
topic:
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine %}
<!-- line left -->
Kindle已经退出中国市场，有点惋惜，国内账号无法通过自动推送邮箱发送到设备了，之前有翻过一些教程，但是没有越狱成功，今天试了下成功越狱于是有了这篇文章，网上的教程已经很详细了，这里我就不再赘述，分享些教程和网站。
{% endpaper %}
</p></div>


## 准备

### Kindle越狱

>  链接：{% icon https://api.iconify.design/solar:link-circle-bold.svg %}[Kindle越狱支持一览：检查 Kindle设备能否越狱](https://bookfere.com/post/406.html)

我的是kindle8这是教程链接，使用的教程是[Kindle 通用越狱教程：适用版本小于等于 5.16.2.1.1 固件](https://bookfere.com/post/1075.html)

注意这一步，速度要{% mark 快 color:red %}

> 依次点击【销售设备→销售】按钮，稍等片刻等待“Kindle按钮示意图”出现；一旦屏幕出现“Kindle按钮示意图”，立即用USB数据线将Kindle连到电脑；

基本上一次成功。

{% swiper effect:cards %}
![](5.jpg)
![](1.jpg)
![](2.jpg)
![](3.jpg)
![](4.jpg)
{% endswiper %}

### 越狱插件

>  Kindle越狱插件：{% icon https://api.iconify.design/solar:link-circle-bold.svg %}[Kindle越狱插件资源下载及详细安装步骤](https://bookfere.com/post/311.html)

需要先按照教程安装`MobileRead Package Installer (MRPI) — 插件安装器`和`KUAL — 插件程序启动器`

我在安装USBNetwork Hack插件时遇到无法通过ssh访问设备的问题，我同时还参考了[Installing USBNetwork (SSH service) on Kindle](https://www.znjoa.com/2023/07/26/installing-usbnetwork-on-kindle/)中{% mark SSH via USB color:red %}节提到需要在搜索栏输入{% mark ;un color:red %}才能打开ssh服务。

安装完之后不得不说上传下载文件真是舒服多了，不用每次通过usb连接。

另外 python 插件应该是有pip的，可以去python目录下，原本的python库是不带`socker`的，去Python二进制文件目录下调用pip安装socker即可。后面可以使用pip安装其他库，运行自动化程序。


<div id="first_down"><p>
{% paper style:underline title:<<<文末闲语>>> author:Phosphine %}
<!-- line left -->
通过网上的使用美国亚马逊账号设置设备可以像之前那样推送书籍。一顿操作之后把之前在 `documents` 的文件都清空了，后悔没有提前备份，有一些用于操作插件的文件也清空了。但是越狱效果还是在，能通过ssh连接设备。重新安装一次[KUAL — 插件程序启动器](https://bookfere.com/post/311.html#p_2)就可以正常使用了。并且多出来的异常文本书籍可以删除，删除后到目前为止没遇到异常。
{% endpaper %}
</p></div>




<!-- 
Category：

理论：理论知识技能，技术
应用：应用笔记，实操
折腾：折腾折腾折腾折腾！(其实属于应用，但就是玩！)
方法：方法论（经验谈），如工程方法
工具：针对具体工具的介绍、使用方法、分析适用场景等；使用工具如何如何解决具体问题，应该放在「应用」里
作品：自己的作品（成品）、个人项目日志等
杂谈：生活碎碎念
自然科学：物理，化学，数学
其他：没法分类的东西

Tags

细分领域：机器之脉络(硬件),机器之魂魄(嵌入式软件,机器学习，算法等),机器之骨骼(结构),
形式：日志
具体内容：个人作品、方法论、随笔
语言：python C C# Java Html micropython 微信小程序
IDE：Arduino CUBEIDE Vscode
自然科学：代数 几何 概率 黑洞 白矮星 四维空间...
IC OR IDE : STM32 ESP32 ESP8266 C51 树莓派 RK3399 野火开发版 MIQI
模组：ws2812b
系统：Linux Windows macOS openwrt Docker   termux
游戏：MC
博客：hexo 主题 魔改
折腾系类：黑苹果，整服务器，termux

 -->


