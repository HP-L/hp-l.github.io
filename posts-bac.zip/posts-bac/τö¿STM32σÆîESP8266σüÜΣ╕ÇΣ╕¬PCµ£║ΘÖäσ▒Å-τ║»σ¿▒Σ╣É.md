---
title: DIY PC机副屏
cover: /headimg/headimg/headimg_10.jpg
banner: /headimg/headimg/headimg_10.jpg
thumbnail: /headimg/headimg/headimg_10.jpg
index_img: /headimg/headimg/headimg_10.jpg
banner_img: /headimg/headimg/headimg_10.jpg
poster:
  topic: null
  headline: null
  caption: null
  color: null
tags:
  - STM32
  - ESP8266
  - HAL
categories:
  - 作品
date: 2024-07-01 18:41:30
topic: 
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine %}
<!-- line left -->
前段时间自己做了一套M910X的亚克力外壳，设计之初考虑到侧面能够添加自己的副屏，再加上曾做过点阵RGB，于是也设置了防止RGB点阵的位置。最初的想法是在这个设备上显示视频，但是刷新率太低了，没有做到 24fps ，放弃了显示视频，转而用了一个简单的PC机副屏，显示一些电脑性能信息，比如CPU频率，内存使用情况，硬盘使用情况，网络情况等等。另外这个副屏外面还做了一圈 RGB。
这个副屏由这几个部分组成，四块 SPI ST7735 屏幕（160\*128\*4）和一圈ws2812b 灯珠组成，主控是 STM32F103C8T6 和 ESP8266组成。stm32 主要作用是控制屏幕刷新和点亮 RGB ，esp8266 主要作用是通过串口发送 json 数据，让 STM32 解析显示。
{% endpaper %}
</p></div>



这个副屏由这几个部分组成，四块 SPI ST7735 屏幕（160\*128\*4）和一圈ws2812b 灯珠组成，主控是 STM32F103C8T6 和 ESP8266组成。stm32 主要作用是控制屏幕刷新和点亮 RGB ，esp8266 主要作用是通过串口发送 json 数据，让 STM32 解析显示。

{% grid %}

<!-- cell -->
{% grid %}

<!-- cell -->
{% grid w:50px%}
{% endgrid %}
<!-- cell -->
{% grid %}
{% image 3.jpg 飞线 download:3.jpg %}
{% endgrid %}

{% endgrid %}
<!-- cell -->

{% grid %}
{% image 1.jpg 亚克力外壳 download:1.jpg %}
{% image 4.jpg 亚克力外壳 download:4.jpg %}
{% endgrid %}
<!-- cell -->

{% endgrid %}


**下面是副屏**

{% image 2.jpg 副屏 download:2.jpg %}

{% image UI.jpg 副屏UI download:UI.jpg %}

## 硬件部分

SPI ST7735这部分硬件设计，四块屏幕共用一组SPI，通过不同的CS来控制不同的屏幕显示。原本有做背光控制，但是买回来的屏幕上电后背光默认开启，有面有空再研究研究啥情况。


{% image 12.png 12 download:12.png %}

layout

{% image 11.png 11 download:11.png %}

3D 图

{% image 3D_左侧USB3.0拓展卡.png 3D_左侧USB3.0拓展卡 download:3D_左侧USB3.0拓展卡.png %}

### 关于背光控制电路

背光控制需要使用pwm调光，买回来的屏幕问了客服说不支持调光，我看了下lcd的板子，上面的背光电路被强行打开了，所以调不了。重新返工屏上线路后如下图，左侧是修改前，右侧是修改后 + 板上电路。将`R148`与`3V3`断开，`BLK`引脚连接主板控制引脚。当`BL_CTRL_PWM`为低电平时 $U_{GS}<0$ ，有压差导通，`BLK`信号高电平。裸屏背光信号`BL`与`GND`导通，有电流流过，背光亮，反之背光暗。

{% image pwm调背光.png pwm调背光 download:pwm调背光.png %}

## 软件部分

### 时序设计

第一次做时序打算使用GPIO外部中断，但实际测试，想用GPIO外部中断，发现中断触发时序概率性错乱导致卡死，所以换成了串口中断。

{% folding  open:false color:red 这是条失败的路 %}

#### 时序框图

这个时序框图不是完整的，有些细节部分没有写出来，但是大致思路是这样

{% image 时序.png 时序框图 download:时序.png %}

这是实际时序

{% image 6.png 时序 download:6.png %}

#### 调试过程

过程中遇到些许问题，有时候调得头皮发麻，一整天愣是解不出来

下图是第一次进入中断时也就是发送字符长度的时候

{% image 5.png Debug1 download:5.png %}

放大之后是这样的

{% image 7.png Debug1放大 download:7.png %}

中断进入debug ，奇怪的是我的代码中串口发送是写在进入STM32 触发中断（GPIO6 边沿触发）后的

{% image 8.png esp8266片段代码截图 1 download:8.png %}

实际效果不影响 STM32 串口接收数据。这是实际效果

{% image 10.png  STM32 串口接收数据 download:10.png %}

{% image 9.png  实际效果 1 download:9.png %}

{% endfolding %}

下面讲成功的时序

#### 时序总图

{% image 时序总图.png  时序总图 download:时序总图.png %}

时序大概是这样：

- 8266：上电初始化->连接WiFi->主循环侦测UDP连接
- STM32： 上电初始化->打开串口中断->进入主循环显示

#### 调试过程

##### 上电瞬间及初始化

{% note color:blue 此处解决8266上电过程中串口有段杂波干扰STM32串口接收 %}

上电瞬间ESP8266串口会有一小段杂波，最初做GPIO外部中断就是为了避免这部分，但是最终想了很多办法没有解决。如下图D1通道，前面一小段就是杂波。右边的两小段下拉是连接Wi-Fi时发送的数据`.`。

{% image 上电瞬间时序总图.png  上电瞬间时序总图 download:上电瞬间时序总图.png %}

这里是初始化HAL库函数和四块屏幕后，进入while循环前的代码，可以看到右侧2处D1和D0通道就是串口中断产生的结果，由于一次直接收一个字符，所以把异常数据都挤掉了。猜测1处可能是拉高后打开了 串口中断，进入中断后又被拉低了。

{% image 上电初始化时序.png  上电初始化时序 download:上电初始化时序.png %}

{% image 代码截图1.png  代码截图1 download:代码截图1.png %}

下面是中断放大后的时序图以及对应的代码，高电平一直触发单个字节接收中断。

{% image 时序代码截图_1.png  时序代码截图_1 download:时序代码截图_1.png %}

```c
		/* 高电平 接收数据 */
		if (pin_pb6_value == 1) {
			/* 回复8266，GPIO拉底 解锁 已经完成第一字节串口接收 */
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
			/* 串口 1debug */
			HAL_UART_Transmit(&huart1, &USART_RX_LINE,
					atoi(USART_RX_ONE_LINE) + 1, 100);

			CS++;
			if(CS>4){
				CS = 1;
			}

			/* 串口中断开启接收长度 1 */
			HAL_UART_Receive_IT(&huart2, &USART_RX_ONE_LINE_LEN, 1);

		}
```

##### 串口中断部分

这是串口中断部分时序

{% image 串口中断放大图.png  串口中断放大图 download:串口中断放大图.png %}



{% folding child:codeblock open:false 串口中断代码片段 %}
```c
/****************************************************************************
 * 函数名: HAL_UART_RxCpltCallback()
 * 功 能: 串口中断函数
 * 输 入: None
 * 全局变量 ALL
 * 输 出: 无
 */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
	if (huart->Instance == USART2) // ???????????? USART1
	{
		/* 串口 1debug */
		HAL_UART_Transmit(&huart1, "IN UART_RxCpltCallback\n", 23, 100);
		/*判断 PB6 为上升或下降沿触发*/
		pin_pb6_value = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6);
		/* 高电平 接收数据 */
		if (pin_pb6_value == 1) {
			/* 回复8266，GPIO拉底 解锁 已经完成第一字节串口接收 */
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
			/* 串口 1debug */
			HAL_UART_Transmit(&huart1, &USART_RX_LINE,
					atoi(USART_RX_ONE_LINE) + 1, 100);
			CS++;
			if (CS > 4) {
				CS = 1;
			}
			/* 串口中断开启接收长度 1 */
			HAL_UART_Receive_IT(&huart2, &USART_RX_ONE_LINE_LEN, 1);
		}
		/* 低电平 接收长度 */
		if (pin_pb6_value == 0) {
			/* 串口 1debug */
			HAL_UART_Transmit(&huart1, "pin_pb6_value == 0\n", 19, 100);
			/* 回复8266，GPIO拉底 解锁 已经完成第一字节串口接收 */
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_RESET);
			/* 串口 1debug */
			HAL_UART_Transmit(&huart1, "GPIO7 DOWN\n", 11, 100);
			/* 串口 2 接收长度2 */
			HAL_UART_Receive(&huart2, &USART_RX_ONE_LINE,
					atoi(USART_RX_ONE_LINE_LEN) + 2, 0xFFFF);
			/* 回复8266，GPIO拉高 已经完成第二字节串口接收 */
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_7, GPIO_PIN_SET);
			/* 串口 1debug */
			HAL_UART_Transmit(&huart1, "GPIO7 UP\n", 9, 100);
			/* 串口 1debug */
			HAL_UART_Transmit(&huart1, "\n############################\n", 30,
					100);
			/* 串口 1debug */
			HAL_UART_Transmit(&huart1, &USART_RX_ONE_LINE_LEN, 1, 100);
			/* 串口 1debug */
			HAL_UART_Transmit(&huart1, "\n############################\n", 30,
					100);
			/* 串口 1debug */
			HAL_UART_Transmit(&huart1, &USART_RX_ONE_LINE,
					atoi(USART_RX_ONE_LINE_LEN) + 2, 100);
			/* 串口 1debug */
			HAL_UART_Transmit(&huart1, "\n############################\n", 30,
					100);
			/* 开启下一次接收数据内容中断 */
			HAL_UART_Receive_IT(&huart2, &USART_RX_LINE,
					atoi(USART_RX_ONE_LINE) + 2);
		}
	}
}
```
{% endfolding %}



下面是三个串口数据发送过程

###### 第一步

获取{% emp 数据长度的长度 %}

{% note color:yellow 预发送长度为1045长度的字符串，1045的长度为4，这里指的就是4 %}

ESP8266 拉低 GPIO6 做准备，接着ESP8266发送串口数据触发STM32串口中断。

{% image 串口中断放大图1.png  串口中断放大图1 download:串口中断放大图1.png %}

###### 第二步：

获取{% emp 数据的长度 %}

上一步完成接收进入中断，STM32拉高GPIO7，进入阻塞串口接收，此时ESP8266（串口中断放大图2）ESP8266等待100ms后发送数据长度，STM32接收完成拉高GPIO7，ESP8266退出死循环进入下一步发送数据内容。STM32退出中断前打开串口中断，准备接收数据。

{% image 串口中断放大图2.png  串口中断放大图2 download:串口中断放大图2.png %}



对ESP8266应代码如下，等待GPIO7被拉高。

```c++
        // 打印长度 尾部带有\r
        Serial.print(static_cast<int>(strlen(substring)));

        delay(100);

        // 打印长度
        Serial.println(Tcp_len);

        // 等待STM32响应，调试需注释
        while (!digitalRead(4)) {  //等待响应
          delay(80);
        }
```

###### 第三步：

获取{% emp 数据内容 %}

上一步GPIO7被拉高后，ESP8266发送数据内容，STM32进入串口中断，识别到GPIO7为高，拉低GPIO7，打开串口中断，STM32准备接收下一次数据长度的长度。

{% image 串口中断放大图3.png  串口中断放大图3 download:串口中断放大图3.png %}

时序设计部分到这里就结束了。

### UI

UI部分是直接使用st7735驱动中自带的，简单做了下，自己做的部分主要是换字体，换成了霞鹜文楷等宽。这部分我没有去看具体显示文本的流程，暂时阶段是能用就行。

关于图像显示，我在[Image转RGB565工具](https://hp-l.github.io/2024/07/09/115544/)放了两个摁钮，可以将RGB图像转成RGB565的字符串，目前颜色部分好像还是有点问题（原本蓝色在屏上会显示出绿色），但是基本形状是正确的。

{% link https://hp-l.github.io/2024/07/09/115544/ Image转RGB565工具 icon:/headimg/headimg/headimg_34.png %}

<div id="first_down"><p>
{% paper style:underline title:<<<文末闲语>>> author:Phosphine %}
<!-- line left -->
久违的代码激情占用了几乎所有的时间，后面的慢慢更新固件吧，第一次做了一个完整的双主控项目。其实一个PC机也是如此，CPU是主控，微控制器也是主控，较老的机型还分南北桥，相互访问的桥梁就是PCB上的电路。说起来PC很复杂，但也很简单。
<!-- line left -->
公元2024年了，科技越来越进步，我想，CPU的终极形态是将一切的一切集成起来吧，ssd，内存，显卡，wifi等等外设，也不知道那是硬件工程师会不会失业哈哈哈哈哈哈哈。也许想得太多太远，当下还应好好进步，在深度学习和智能AI的时代，layout可能会被替代，那时会不会机器人能自建工厂自行组装呢。。。就好像生物的繁衍一样。。。
{% endpaper %}
</p></div>



<!-- 
Category：

理论：理论知识技能，技术
应用：应用笔记，实操
折腾：折腾折腾折腾折腾！(其实属于应用，但就是玩！)
方法：方法论（经验谈），如工程方法
工具：针对具体工具的介绍、使用方法、分析适用场景等；使用工具如何如何解决具体问题，应该放在「应用」里
作品：自己的作品（成品）、个人项目日志等
杂谈：生活碎碎念
自然科学：物理，化学，数学
其他：没法分类的东西

Tags

细分领域：机器之脉络(硬件),机器之魂魄(嵌入式软件,机器学习，算法等),机器之骨骼(结构),
形式：日志
具体内容：个人作品、方法论、随笔
语言：python C C# Java Html micropython 微信小程序
IDE：Arduino CUBEIDE Vscode
自然科学：代数 几何 概率 黑洞 白矮星 四维空间...
IC OR IDE : STM32 ESP32 ESP8266 C51 树莓派 RK3399 野火开发版 MIQI
模组：ws2812b
系统：Linux Windows macOS openwrt Docker   termux
游戏：MC
博客：hexo 主题 魔改
折腾系类：黑苹果，整服务器，termux

 -->


