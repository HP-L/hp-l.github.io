---
title: 解决安卓端 Kindle APP无法与 Kindle 硬件同步
cover: /headimg/headimg/headimg_20.jpg
banner: /headimg/headimg/headimg_20.jpg
thumbnail: /headimg/headimg/headimg_20.jpg
index_img: /headimg/headimg/headimg_20.jpg
banner_img: /headimg/headimg/headimg_20.jpg
poster:
  topic: null
  headline: null
  caption: null
  color: null
tags:
  - Kindle
  - Amazon
categories:
  - 应用
published: true
date: 2024-12-03 12:50:11
topic:
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine date:二〇二四年十二月三日 %}
<!-- line left -->
在 18 年前后入手 Kindle 8，官方价 558 ，高中经常用，大学积了 4 年灰...最近这半年来又开始用起来了，路上看看书什么的。
{% endpaper %}
</p></div>

亚马逊 Kindle 业务退出了中国市场，随之带来了很多问题，我的国行 Kindle 无法享用云端存储和同步功能了，不得不转移到美区账户。

转美区账户也简单，网上有教程，这里也不再赘述，Kindle 最好用的功能之一就是多端同步，忘记带 Kindle 或者不方便带时可以用手机无缝衔接，非常方便。但因为退出中国市场之后手机 App 没办法同步了，一加应用商城下载的登录自己账号没有问题，但是无法同步；国际版的 App 账号密码一输入就返回到主界面，根本没有登录成功。

后来我发现了一个问题，他的商城界面自动链接到了中国亚马逊官网，这就有点问题了，通过连接节点登录理论上会记录节点 IP 进而进行定位，但他的逻辑好像不是这样，我回想起同步 Kindle8 硬件的时候有个操作是将语言设置为英文，于是我便试了试将手机的语言设置成英文，果然再开启 App 的时候商城自动选择了亚马逊官网而不是中国亚马逊官网，接着登录账号就直接同步了！传书成功。

{% image /headimg/weeknote/202449/1.jpeg  kindle width:200px padding:16px %}

## ~~正文~~

1. 将设备语言更换成英文
2. 打开 Kindle App 登录账号
3. 耐心等待登录即可
4. 同步成功后返回设置界面调回中文

<!-- ## _还没写完.._ -->


<div id="first_down"><p>
{% paper style:underline title:<<<文末闲语>>> author:Phosphine %}
<!-- line left -->
这小半年来只读了几本书，感触最大的就是读得太慢了，还是需要提升一下阅读速度，觉得离一分钟 500 字还差得远，而且读的时候部分人物场景的描述也没有细读，有诸多细节会被忽略，路漫漫其修远兮，慢慢走吧～
{% endpaper %}
</p></div>


<!-- 
Category：

理论：理论知识技能，技术
应用：应用笔记，实操
折腾：折腾折腾折腾折腾！(其实属于应用，但就是玩！)
方法：方法论（经验谈），如工程方法
工具：针对具体工具的介绍、使用方法、分析适用场景等；使用工具如何如何解决具体问题，应该放在「应用」里
作品：自己的作品（成品）、个人项目日志等
杂谈：生活碎碎念
自然科学：物理，化学，数学
其他：没法分类的东西

Tags

细分领域：机器之脉络(硬件),机器之魂魄(嵌入式软件,机器学习，算法等),机器之骨骼(结构),
形式：日志
具体内容：个人作品、方法论、随笔
语言：python C C# Java Html micropython 微信小程序
IDE：Arduino CUBEIDE Vscode
自然科学：代数 几何 概率 黑洞 白矮星 四维空间...
IC OR IDE : STM32 ESP32 ESP8266 C51 树莓派 RK3399 野火开发版 MIQI
模组：ws2812b
系统：Linux Windows macOS openwrt Docker   termux
游戏：MC
博客：hexo 主题 魔改
折腾系类：黑苹果，整服务器，termux

 -->


