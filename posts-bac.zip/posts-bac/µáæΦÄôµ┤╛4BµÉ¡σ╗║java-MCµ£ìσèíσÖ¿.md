---
title: 树莓派4B搭建java MC服务器
banner: /headimg/headimg/headimg_18.png
cover: /headimg/headimg/headimg_18.png
thumbnail: '/headimg/headimg/headimg_18.png'
index_img: '/headimg/headimg/headimg_18.png'
banner_img: /gallery/55.jpeg
date: 2022-06-08 12:07:05
tags: 
  - 树莓派
  - MC
categories: 应用
---

## Java 安装

安装java17，三个版本可以同时安装
```shell
sudo apt update
sudo apt install default-jdk
sudo apt install openjdk-8-jdk
sudo apt install openjdk-11-jdk
sudo apt install openjdk-17-jdk
```
选择默认java版本，跟换成17

```shell
sudo update-alternatives --config java
```

## 服务器构建器下载及其安装

[下载链接](https://files.minecraftforge.net/net/minecraftforge/forge/index_1.18.2.html)

[所有版本](https://files.minecraftforge.net/net/minecraftforge/forge/)

点击下载

![1.png](1.png)

或者：

```
wget https://maven.minecraftforge.net/net/minecraftforge/forge/1.18.2-40.1.48/forge-1.18.2-40.1.48-installer.jar
```

安装

```
java -jar forge-1.18.2-40.1.48-installer.jar -install
```

会弹出图形界面，记住安装目录，选择服务器，安装完成。

## 运行服务器

cd 到forge安装目录，linux运行

```
./run.sh
```
没有 eula=true 会报错，新建或者直接编辑eula即可。

配置eula.txt，没有文件可以直接新建一个，在forge的安装目录的根目录直接写入即可。

```
eula=true
```

## 客户端使用

如果是PCL2启动器需要先安装 forge mod，pcl2 进入 mod 查找点开下载文件，手动双击jar安装，这里选择客户端，安装完成后 PCL2 启动 forge 即可，启动后输入IP+端口号码，默认端口25565。