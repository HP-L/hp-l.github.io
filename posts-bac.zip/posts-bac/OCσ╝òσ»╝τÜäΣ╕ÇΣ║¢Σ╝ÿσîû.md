---
title: OC引导的一些优化
cover: /headimg/headimg/headimg_37.png
banner: /headimg/headimg/headimg_37.png
thumbnail: /headimg/headimg/headimg_37.png
index_img: /headimg/headimg/headimg_37.png
banner_img: /headimg/headimg/headimg_37.png
poster:
  topic: null
  headline: null
  caption: null
  color: null
tags:
  - opencore
  - boot
categories:
  - 折腾
date: 2024-10-21 11:02:34
topic: ️hackintosh
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine date:二〇二四年十月二十一日 %}
<!-- line left -->
做好 EFI 后总看着 Win 的引导不太舒服，Ubuntu 还需要手动进 bios，不太方便，干脆一起优化一下，记录了本文教程
{% endpaper %}
</p></div>


## 图标制作
先讲一下图标的制作，可以用我下面写的这个脚本（该脚本只用于制作 磁盘这样的方形图标）

新建文件`make_icns`，不需要添加后缀，右键文本编辑器打开，复制以下内容到文件并保存，最后进入终端输入`chmod +X make_icns`

```shell
mkdir icons.iconset

sips -z 16 16 icon.png -o icons.iconset/icon_16x16.png
sips -z 32 32 icon.png -o icons.iconset/icon_16x16@2x.png
sips -z 32 32 icon.png -o icons.iconset/icon_32x32.png
sips -z 64 64 icon.png -o icons.iconset/icon_32x32@2x.png
sips -z 128 128 icon.png -o icons.iconset/icon_128x128.png
sips -z 256 256 icon.png -o icons.iconset/icon_128x128@2x.png
sips -z 256 256 icon.png -o icons.iconset/icon_256x256.png
sips -z 512 512 icon.png -o icons.iconset/icon_256x256@2x.png
sips -z 512 512 icon.png -o icons.iconset/icon_512x512.png
sips -z 1024 1024 icon.png -o icons.iconset/icon_512x512@2x.png

iconutil -c icns icons.iconset -o icon.icns

rm -r icons.iconset
```

使用方法：
1. 先将需要变更的 png 文件和刚才做好的`make_icns`放在桌面上
2. 双击`make_icns`

{% image 2.png  制作icns download:2.png %}

## 添加盘符显示图标
一共有两种方式，磁盘添加`.contentFlavour`文件和 plist 文件修改

### 磁盘添加 `.contentFlavour`

找到 Windows 的 efi 磁盘：`\EFI1\Microsoft\Boot\`，在该文件夹下添加文件，输入内容
{% copy Windows11:Windows %}
如果是Win10
{% copy Windows10:Windows %}

同步添加文件`Windows11.icns`到主题文件夹下。

### plist文件修改方式

这里以 linux 为例

如图添加

{% image 1.png  oc截图 download:1.png %}

同样你需要添加`ubuntu2404.icns`到主题文件夹下

效果图：
{% image /headimg/headimg/headimg_37.png  oc效果图截图 download:/headimg/headimg/headimg_37.png %}

## 添加 Linux 磁盘引导

首先需要添加`Openshell.efi`
{% image 4.png  oc截图 download:4.png %}

1. 重启进入`UEFI SHELL`
2. 找到 `Ubuntu` 存储的盘符名称，我的是`FS1:`（其实这里只需要找一个地方存储 txt 文件就可以，至于是不是 EFI 无所谓，但你要知道 Ubuntu 的 efi 是存在那个盘符的）
3. 进入磁盘后输入

{% copy map > map_table_linux.txt %}

重启后打开文件如图，这里重点找存放 ubuntu 启动的 efi 的磁盘，我存放 Ubuntu 的引导盘和 OC 引导盘不在同一个盘，可能和其他博主的教程不太一样
{% image 5.png  map_table_linux download:5.png %}

4. 添加到 boot 中

{% image 1.png  map_table_linux download:1.png %}


## _持续更新.._

<!-- 
<div id="first_down"><p>
{% paper style:underline title:<<<文末闲语>>> author:Phosphine %}
<!-- line left -->
正文文末闲语
{% endpaper %}
</p></div>
 -->

> 参考链接：
> 1. [「国光」OC 主题与启动项](https://apple.sqlsec.com/6-%E5%AE%9E%E7%94%A8%E5%A7%BF%E5%8A%BF/6-10/#_6)
> 1. 「知乎」使用Opencore引导ubuntu以及Linux的步骤(https://zhuanlan.zhihu.com/p/256400835)

<!-- 
Category：

理论：理论知识技能，技术
应用：应用笔记，实操
折腾：折腾折腾折腾折腾！(其实属于应用，但就是玩！)
方法：方法论（经验谈），如工程方法
工具：针对具体工具的介绍、使用方法、分析适用场景等；使用工具如何如何解决具体问题，应该放在「应用」里
作品：自己的作品（成品）、个人项目日志等
杂谈：生活碎碎念
自然科学：物理，化学，数学
其他：没法分类的东西

Tags

细分领域：机器之脉络(硬件),机器之魂魄(嵌入式软件,机器学习，算法等),机器之骨骼(结构),
形式：日志
具体内容：个人作品、方法论、随笔
语言：python C C# Java Html micropython 微信小程序
IDE：Arduino CUBEIDE Vscode
自然科学：代数 几何 概率 黑洞 白矮星 四维空间...
IC OR IDE : STM32 ESP32 ESP8266 C51 树莓派 RK3399 野火开发版 MIQI
模组：ws2812b
系统：Linux Windows macOS openwrt Docker   termux
游戏：MC
博客：hexo 主题 魔改
折腾系类：黑苹果，整服务器，termux

 -->


