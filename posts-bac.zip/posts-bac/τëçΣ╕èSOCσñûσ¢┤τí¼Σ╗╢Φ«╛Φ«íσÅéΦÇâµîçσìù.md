---
title: 片上SOC外围硬件设计参考指南
cover: /headimg/headimg/headimg_22.jpg
banner: /headimg/headimg/headimg_22.jpg
thumbnail: /headimg/headimg/headimg_22.jpg
index_img: /headimg/headimg/headimg_22.jpg
banner_img: /headimg/headimg/headimg_22.jpg
poster:
  topic: null
  headline: null
  caption: null
  color: null
tags:
  - 技术文章
categories:
  - 理论
published: true
date: 2025-01-15 19:38:49
topic: e-sth
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine date:二〇二五年一月九日 %}
<!-- line left -->
本文的初衷是希望能让非电学专业的人能看明白，就像24年更新的[🔗元器件之旅](/tags/元器件之旅/)一样（但是得懂一点高数）。
{% endpaper %}
</p></div>

## 总则

硬件设计不仅仅是原理重要，layout 也非常重要，layout是讲硬件线路变成现实的一环，这其中的原理相当的多，高压、低压、SI、EMI各不相同。

本文简述片上SOC需要的硬件接口和电源部分以及功能接口，是概述，每一部分后面可以单独出一篇细讲原理，具体细致到某一种协议，某一种平台电源方案都需要具体情况具体分析，篇幅不想写太长了，后面会把所有谈到的部分逐一展开讲解，每种设备的硬件原理以及涉及到的通信协议时序逻辑。

> 本文均参考自网友文章和CPU厂商参考设计文档。



## 最小系统设计建议

### 晶振

{% image /article/2025/01/001.png 晶体连接方式及器件参数 %}

> 电容C1102、C1103的值需要根据晶体的实际标称负载电容值选择，8pF为原厂选用晶体所对应容值，不为通用值。

部分芯片会说明晶振工作的作用，比如RK3399提到：芯片在待机时，会将内部时钟源切换到外接的32.768KHz时钟，通过降低工作频率以降低系统功耗。

这里只举到了RK3399这种IC，对于大到intel和AMD，小到STM32等微控制器都是一样的逻辑。晶振是芯片的脉搏来源，是各种数电骚操作的根基。

> 参考本站文章（挖个坑，稍后补）-->[晶体谐振器与负载电容及其计算方法](/)

### 复位电路

{% image /article/2025/01/002.png 复位线路 %}

复位也是很重要的操作，当IC跑飞可以通过复位让其重新启动。这个连C51都有，不多做介绍。（多提一句，这个电容C1100是用来消抖的，开关摁下瞬间并不是理想瞬间拉低，在某一瞬间是会产生抖动的，波形不稳定，这里利用电容电压瞬间不可变的特性实现消抖，想详细了解可以量测开关摁下时的波形或者百度。）

### Debug

#### JTAG
协议举例：[ IEEE 1149.1 (JTAG) Boundary-Scan
 Testing for MAX II Devices](https://www.intel.com/programmable/technical-pdfs/655055.pdf)

JTAG信号引脚一共有4个或者5个（其中一个可选）。这些引脚仅用于测试目的，控制JTAG完成1149.1协议的操作。引脚信息如下：

- **Test clock input（TCK）**：该引脚为测试逻辑提供时钟，由于受板级以及芯片pad限制，一般频率为10MHz，频率占空比一般为50%。TMS和TDI的数据在TCK的上升沿被采样。数据在时钟的下降沿输出到TDO。**建议下拉**。

- **Test mode select input（TMS）**：用于控制JTAG内部状态机跳转，切换到指定，该信号在TCK上升沿时被采样。TMS用来设置JTAG口处于某种特定的测试模式，用于控制TAP状态机。**必须上拉。**

- **Test data input（TDI）**：输入到指令寄存器（IR）或数据寄存器（DR）的数据出现在TDI输入端，在TCK的上升沿被采样。建议上拉，**上拉电阻阻值不能小于1K**。

- **Test data output（TDO）**：来自指令寄存器或数据寄存器的数据在时钟的下降沿被移出到TDO。**不用上下拉**，悬空时，尽量引出测试点，同时应避免将TDO作为I/O使用。

- **Test reset input（TRST*）**：JTAG 内部逻辑全局异步复位信号，**一般低电平有效**。TRST可以用来对TAP Controller进行复位（初始化）。因为通过TMS也可以对TAPController进行复位（初始化）。所以有四线JTAG与五线JTAG之分。

- **可选引脚RTCK**：测试时钟返回信号。RTCK由目标端反馈给仿真器的时钟信号，用来同步TCK信号的产生，不使用时直接接地。

- **可选引脚nSRST**：目标系统复位信号。与目标板上的系统复位信号相连，可以直接对目标系统复位。同时可以检测目标系统的复位情况，为了防止误触发应在目标端加上适当的上拉电阻。

#### SWD

- **VRef**：目标板参考电压信号。用于检查目标板是否供电，直接与目标板VDD联，并不向外输出电压(**必须**)

- **GND**：公共地信号(**必须**)

- **SWDIO**：串行数据输入输出，作为仿真信号的双向数据信号线，建议上拉(**高速下载时一定需要上拉**，**必须**)

- **SWCLK**：串行时钟输入，作为仿真信号的时钟信号线，建议下拉(**高速下载时一定需要下拉**，**必须**)

- **SWO**：串行数据输出引脚，CPU调试接口可通过SWO引脚输出一些调试信息。该引脚是**可选的**

- **RESET**：仿真器输出至目标CPU的系统复位信号。该引脚**可选**，建议选择上，因为ULINK是一定需要该管脚的，使得仿真器能够在连接器件前对器件进行复位，以获得较理想的初始状态，便于后续连接仿真。

### DDR电路

{% image /article/2025/01/003.png RK3399DDR3拓扑 %}

对于内存来说，细节非常多，可以单独出一篇文章了，这里仅仅给出了RK3399DDR3拓扑，大概看下有哪些线需要链接上。每一代的DDR都有自己的标准DDR3和DDR4的标准就不太一样，具体情况具体分析。

DDR3上电时序如下：

{% image /article/2025/01/004.png DDR3上电时序 %}

### eMMC电路

线路上一般直接连接就可以，没有上下拉电阻要求。当然，这类存储设备在进入休眠时会有掉电上电需求，具体情况看CPU的规格书，上面会详细说明如何开关电源。

- **eMMC_DQ[7:0]**：eMMC数据发送/接收
- **eMMC_CLK**：eMMC时钟发送
- **eMMC_CMD**：eMMC命令发送/接收
- **eMMC_STRB**：HS400模式下，eMMC时钟接收软件配置内部下拉，无需外部下拉电阻。

### SPI

为什么SPI也列入最小系统设计中？许多比较复杂的芯片如FPGA、CPU等等都有从SPI启动，比如BIOS就是SPI通信（严格来说不是标准SPI）。

- **SPI1_TXD（MOSI）**：SPI数据发送
- **SPI1_RXD（MISO）**：SPI数据接收 
- **SPI1_CLK**：SPI时钟发送，串联22ohm电阻 （这个电阻应该是阻抗匹配时用到的）
- **SPI1_CSn0**：SPI片选信号

## 电源系统设计简述

电源方案在这里不好讲，因为每个芯片都不一样，先举个例子。

### X86

以前的 **Intel CPU** 电源方案采用的是 Controller+DrMOS ，具体如下图：

{% image /article/2025/01/005.png 经典Controller+DrMOS模型 %}

可以精准控制几路电源输出，CPU的电压很低但是电流非常大 80A+ 都是正常的（用功率计算公式反推一下就能知道，假设电压是0.9V），最新出的Lunar Lake的 DDR 部分已经和 CPU 绑定在一起了，时序自然也都有要求。

### ARM

而**ARM**架构如瑞芯微或者高通等，他们采用的电源方案不太一样，他们的电源分支非常细致，导致会有非常多的Buck和ldo，例如rk3399使用的RK809-3，有5路Buck和9路ldo。~~大多是抄图的，真正做这些设计从理论到实践的都是原厂，OEM，ODM都是用着就行~~

{% image /article/2025/01/006.png RK809-3简介 %}

{% image /article/2025/01/007.jpg RK3399实际使用的电源数量 %}

## 功能接口设计建议

### 存储卡电路

其实就是TF卡，CPU 中叫做 SDMMC 控制器。硬件层面没什么好说的，把桥搭上，硬件层面就没有了。

- **SDMMC_DQ[3:0]**：SDMMC数据发送/接收，上拉，串联22ohm电阻
- **SDMMC_CLK**：SDMMC时钟发送，下拉
- **SDMMC_CMD**：SDMMC命令发送/接收，上拉 ，串联22ohm电阻

### 以太网口电路 

RMII接口(MAC-to-PHY的RMII)：

- **MAC_TXCLK**：数据发送的参考时钟【串联22ohm电阻】
- **MAC_RXCLK**：数据接收的参考时钟【直连】 
- **MAC_TXD[1:0]**：数据发送 【串联22ohm电阻】
- **MAC_RXD[1:0]**：数据接收【直连】
- **MAC_TXEN**：发送数据使能 【串联22ohm电阻】
- **MAC_RXDV**：接收数据有效指示 【直连】
- **MAC_MDC**：配置接口时钟 【直连】
- **MAC_MDIO**：配置接口I/O 【直连】
- **MAC_CLK**：主时钟输出，50MHz 【串联22ohm电阻】

这是以太网七层链路映射，对于硬件来说，主要是物理层，**数据链路层**主要是**将**不同的传输协议（UDP/TCP）加上其他的层如IP层等等形成的**以太网数据包**转换成**电信号**。

{% image /article/2025/01/008.png 太网七层链路 %}

对于RK3399来说，MAC部分已经集成到CPU中了，不像Intel，需要从PCIE转出来（映像中只有一个平台的有，其他的CPU都没有），设计相对简单些，当然也有MAC和PHY集成方案。

### USB电路

#### USB 2.0

没什么好说的，非常简单。

- +5 VDC
- Data -
- Data +
- Ground

#### USB 3.0

USB 3.0 相比 USB 2.0 多了一个差分信号，速度会快很多，属于高速信号（SI），越高速的信号layout要求越严格，例如TBT等等。

- 针脚编号 1: 红色 - VBUS
- 针脚编号 2: 白色 - D−
- 针脚编号 3: 绿色 - D+
- 针脚编号 4: 黑色 - GND
- 针脚编号 5: 蓝色 - StdA_SSRX− / StdB_SSTX−
- 针脚编号 6: 黄色 - StdA_SSRX+ / StdB_SSTX+
- 针脚编号 7: Shield - 信号地用于降低噪声干扰
- 针脚编号 8: 紫色 - StdA_SSTX− / StdB_SSRX−
- 针脚编号 9: 橙色 - StdA_SSTX+ / StdB_SSRX+

### 音频电路

最常见的是I2S，在I2C基础上做了一点点变更。还有PCM。

- **I2S_SCLK**          下拉   串联22ohm电阻   I2S系统时钟输出，供I2S0&I2S1设备工作 
- **I2S_SCLK**          下拉   串联22ohm电阻   I2S位时钟输出 
- **I2S_LRCK_TX/RX**    下拉   串联22ohm电阻   I2S声道选择输入/输出
- **I2S_SDI0**          下拉   串联22ohm电阻   I2S数据输入通道0 
- **I2S_SDI1SDO3**      下拉   串联22ohm电阻   I2S数据输入通道1/输出通道3
- **I2S_SDI2SDO2**      下拉   串联22ohm电阻   I2S数据输入通道2/输出通道2
- **I2S_SDI3SDO1**      下拉   串联22ohm电阻   I2S数据输入通道3/输出通道1
- **I2S_SDO0**          下拉   串联22ohm电阻   I2S数据输出通道0 

Codec 在这里就暂时不讲了，方案很多，这里写不完。

### 视频电路

#### eDP

{% image /article/2025/01/010.png eDP %}

eDP控制器参考电阻R1704需选用1%精度的电阻，该电阻会影响眼图信号质量；

#### MIPI


{% image /article/2025/01/011.png mipi %}

MIPI-DSI控制器参考电阻R1707需选用1%精度的电阻，该电阻会影响眼图信号质量；

#### HDMI

{% image /article/2025/01/012.png HDMI %}

HDMI 需要注意防倒灌，在 CEC 的 DDC 上需要添加电瓶转换

{% image /article/2025/01/013.png HDMI %}

### 摄像头电路

#### MIPI CSI

{% image /article/2025/01/014.png MIPI-CSI %}

控制器参考电阻R1602&R1603请选用1%精度的电阻，该电阻会影响眼图信号质量；

### UART电路

- **UART_RX**      ： UART数据输入
- **UART_TX**      ： UART数据输出 
- **UART_CTSn**    ： UART允许发送信号 
- **UART_RTSn**    ： UART请求发送信号

### SDIO电路

- **SDIO_DQn[0:3]**   ： 串联22ohm电阻  SDIO数据发送/接收 
- **SDIO_CLKOUT**     ： 直连          SDIO时钟发送 
- **SDIO_CMD**        ： 直连           SDIO命令发送/接收

### SPDIF

SPDIF全称为Sony/Philips Digital Interface Format是SONY、PHILIPS数字音频接口的简称。就传输载体而言，SPDIF又分为同轴和光纤两种，其实他们可传输的信号是相同的，只不过是载体不同，接口和连线外观也有差异。但光信号传输无需考虑接口电平及阻抗问题，接口灵活且抗干扰能力更强。

{% image /article/2025/01/015.png  SPDIF使用同轴接口 %}

### PCIe电路

{% image /article/2025/01/016.png  PCIE %}

TX信号线的耦合电容应靠近PCIe连接座放置，RX电容由设备端提供；

<!-- ## _还没写完.._ -->


<div id="first_down"><p>
{% paper style:underline title:<<<文末闲语>>> author:Phosphine %}
<!-- line left -->
片上SOC设计有非常多细节，复杂的如FPGA和CPU，简单的就是嵌入式微控制器。在电子设计中，大多如此，至少在当前10~20年变化不大，具有科技感的AR、XR都是微型片上SOC。从外围电路设计上其实没有多少难度，核心是光机的光波导镜片以及核心SOC。乍眼一看其实硬件设计原理上基本到头了，除非材料革命。硬件创造世界，软件改变世界。现在这个时代四处充斥着软件的影子，你对手机的每一步操作，对 AI 讲的每一段语音都是软件在起作用，硬件只不过是载体而已。当然不排除芯片设计了，芯片设计是纯粹的硬件设计（可能也不准确，FPGA 之类的又有程序参与），从简单的触发器寄存器，通过复杂的级联成CPU，PC的诞生至今也不过四五十年左右。希望未来能来得更快点。
{% endpaper %}
</p></div>


<!-- 
Category：

理论：理论知识技能，技术
应用：应用笔记，实操
折腾：折腾折腾折腾折腾！(其实属于应用，但就是玩！)
方法：方法论（经验谈），如工程方法
工具：针对具体工具的介绍、使用方法、分析适用场景等；使用工具如何如何解决具体问题，应该放在「应用」里
作品：自己的作品（成品）、个人项目日志等
杂谈：生活碎碎念
自然科学：物理，化学，数学
其他：没法分类的东西

Tags

细分领域：机器之脉络(硬件),机器之魂魄(嵌入式软件,机器学习，算法等),机器之骨骼(结构),
形式：日志
具体内容：个人作品、方法论、随笔
语言：python C C# Java Html micropython 微信小程序
IDE：Arduino CUBEIDE Vscode
自然科学：代数 几何 概率 黑洞 白矮星 四维空间...
IC OR IDE : STM32 ESP32 ESP8266 C51 树莓派 RK3399 野火开发版 MIQI
模组：ws2812b
系统：Linux Windows macOS openwrt Docker   termux
游戏：MC
博客：hexo 主题 魔改
折腾系类：黑苹果，整服务器，termux

 -->


