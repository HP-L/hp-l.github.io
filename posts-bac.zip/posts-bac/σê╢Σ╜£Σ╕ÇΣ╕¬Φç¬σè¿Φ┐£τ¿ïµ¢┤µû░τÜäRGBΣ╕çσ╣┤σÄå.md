---
title: DIY 联网RGB万年历
cover: /headimg/headimg/headimg_7.jpg
banner: /headimg/headimg/headimg_7.jpg
thumbnail: /headimg/headimg/headimg_7.jpg
index_img: /headimg/headimg/headimg_7.jpg
banner_img: /headimg/headimg/headimg_7.jpg
poster:
  topic: null
  headline: null
  caption: null
  color: null
tags:
  - ws2812b
  - esp8266
  - 机器之脉络
categories:
  - 作品
date: 2024-05-04 15:25:34
topic: 
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine %}
<!-- line left -->
今年一月份整理元件箱的时候发现了一个8位RGB灯条，想起网上前段时间流行的 WIFI 像素时钟：LaMetric
{% endpaper %}
</p></div>


![LaMetric](https://lametric.com/sites/default/files/2020-05/desktop.%20jpg.jpg)

正好可以巩固一下曾经写代码的快乐时光，开搞！！手上的灯珠比较大，当时也没有仔细考虑工业设计，就打算做个能用的就行。

下面做了个简单的第一版，其实真的可以优化很多地方，看完不要笑😂😂😂，但是懒得搞了，先用着再说

硬件创造世界，软件让世界更美好，硬件底层搭好了，软件能实现出各种各样的功能，优化人类体验。

{% swiper effect:cards width:max%}

![8.jpg](8.jpg)
![9.jpg](9.jpg)
![1.png](1.png)
![2.jpg](2.jpg)
![3.jpg](3.jpg)
{% endswiper %}

调试的时候拍的

{% swiper effect:cards width:max%}
![4.jpg](4.jpg)
![5.jpg](5.jpg)
![6.jpg](6.jpg)
![7.jpg](7.jpg)
{% endswiper %}


## 硬件设计

硬件设计其实比较简单，我懒到电源直接买了整个模块搭上去。。。就是PCB正面左边二维码区域，PCB正面右边就是8266模块了，背面的是陀螺仪的降压IC

{% image 2.png PCB正面 %}
{% image 3.png PCB背面 %}

### 原理图

硬件预留了18650电池和电量检测部分电路，软件没有还没有做

{% image 4.png 原理图1 %}

这个小项目 RGB 灯有 100 个，也就是`10 * 10 = 100`的点阵，当时没想那么多，结果就是很多图像没有办法展示出来了，LaMetric可是 `4 * 8 * 8 = 256`像素的，按照设计第一版有预留电容，但是背面的图案太不好看了，就直接拿掉了（按道理加电容更加稳定），一百个灯珠，焊接是真的累😮‍💨

{% image 5.png 原理图2 %}

### 功耗测试

实际测试发现，运行彩虹流水灯，也就是功耗拉满的时候过 RGB 灯珠电流达到了 0.9A 左右，也就是5V*09.A=4.5W了，功耗比较高了，再测了测发热量满载都50°C了

{% image 1.jpg 温度 %}

## 软件设计

代码是arduino写的，写了两千多行，代码长了点，不太好展示，基本逻辑就是控制RGB显示图案出来。

下面展示几个联网跟新的操作

### 联网抓取json文件

每天检测两次，看是否有固件更新，一但有就马上判断进入OTA了

{% image 6.png 获取更新 %}

文件格式如下：
```json
{
    "app_version_X": 0, //主版本号
    "app_version_Y": 0, //子版本号
    "app_version_Z": 5, //阶段版本号
    "update": 1, //更新锁
    "MUST_update": 0 //强制更新
}
```

### 通过http网址跟新固件

就这个功能函数我找了好久，网上大部分都是 arduino IDE 更新固件，要不就是局域网跟新，自己整合了一段时间，打包了一个函数，直接拿去使用，记得需要添加头文件

下面这段是更新固件的百分数，实现每增加1%就亮一个灯。
```c++
strip.setPixelColor(((progress / (total / 100))) - 1, (progress / (total / 100)) / 100 * 255 * brightness / 100, (255 - (progress / (total / 100)) / 100 * 255) * brightness / 100, (255 - (progress / (total / 100)) / 100 * 255) * brightness / 100);
```

而`http://V1_0_1_beta.bin`可以替换成自己的固件链接

完整函数如下：
```c++
//必备的头文件
#include <ESP8266WiFi.h>
#include <ESP8266httpUpdate.h>

/**
 * 功能：联网下载固件文件OTA
 * @param NONE
 * @return NONE
 * @example https_OTA();
 * @note NONE
 * @link https://zhuanlan.zhihu.com/p/435855807
 * @history
 * V0.0.1 2024-01-05 初始版本，未能实现功能
 * V0.0.1 2024-01-08 更新变量 UpdateClient，成功升级
 * */
void https_OTA() {
  RGB_GFX_PIC(up_date);
  while (1) {
    // 设置回调函数以获取下载进度
    ESPhttpUpdate.onProgress([](int progress, int total) {
      //注释打印 Serial.printf("Progress: %d%%\n", (progress * 100) / total);
      strip.setPixelColor(((progress / (total / 100))) - 1, (progress / (total / 100)) / 100 * 255 * brightness / 100, (255 - (progress / (total / 100)) / 100 * 255) * brightness / 100, (255 - (progress / (total / 100)) / 100 * 255) * brightness / 100);
      strip.show();
    });

    t_httpUpdate_return ret = ESPhttpUpdate.update(UpdateClient, "http://V1_0_1_beta.bin");
    switch (ret) {
      case HTTP_UPDATE_OK:
        //注释打印 Serial.println("Firmware updated successfully");
        break;
      case HTTP_UPDATE_FAILED:
        //注释打印 Serial.println("Firmware update failed");
        break;
      case HTTP_UPDATE_NO_UPDATES:
        //注释打印 Serial.println("No firmware updates available");
        break;
      default:
        //注释打印 Serial.printf("Firmware update error %d\n", ret);
        break;
    }
  }
}
```

<div id="first_down"><p>
{% paper style:underline title:<<<文末闲语>>> author:Phosphine %}
<!-- line left -->
除了网络信号不好之外，没有出过一次差错，这个小玩意就这样放在那里稳定地运行着。这个版本后续没有再做了，算是一次尝试，毕业后第一次捡回了嵌入式编程，回顾下大学那会敲代码的快乐时光。才几个月没有动，基本上是重新学了，这老本行不能就这样丢了呀，以后再多做些好玩的项目练练手。
{% endpaper %}
</p></div>

<!-- 
Category：

理论：理论知识技能，技术
应用：应用笔记，实操
折腾：折腾折腾折腾折腾！(其实属于应用，但就是玩！)
方法：方法论（经验谈），如工程方法
工具：针对具体工具的介绍、使用方法、分析适用场景等；使用工具如何如何解决具体问题，应该放在「应用」里
作品：自己的作品（成品）、个人项目日志等
杂谈：生活碎碎念
自然科学：物理，化学，数学
其他：没法分类的东西

Tags

细分领域：机器之脉络(硬件),机器之魂魄(嵌入式软件,机器学习，算法等),机器之骨骼(结构),
形式：日志
具体内容：个人作品、方法论、随笔
语言：python C C# Java Html micropython 微信小程序
IDE：Arduino CUBEIDE Vscode
自然科学：代数 几何 概率 黑洞 白矮星 四维空间...
IC OR IDE : STM32 ESP32 ESP8266 C51 树莓派 RK3399 野火开发版 MIQI
模组：ws2812b
系统：Linux Windows macOS openwrt Docker   termux
游戏：MC
博客：hexo 主题 魔改
折腾系类：黑苹果，整服务器，termux

 -->


