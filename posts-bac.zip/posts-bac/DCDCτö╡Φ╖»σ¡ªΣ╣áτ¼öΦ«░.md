---
title: DCDC电路学习笔记
cover: /headimg/headimg/headimg_GIF.gif
banner: /headimg/headimg/headimg_GIF.gif
thumbnail: /headimg/headimg/headimg_GIF.gif
index_img: /headimg/headimg/headimg_GIF.gif
banner_img: /headimg/headimg/headimg_GIF.gif
poster:
  topic: null
  headline: null
  caption: null
  color: null
tags:
  - BUCK
  - 机器之脉络
categories:
  - 理论
date: 2024-09-25 16:33:49
topic: e-sth
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine %}
<!-- line left -->
电源就像是心脏，电流就像是血液，电压就像是脉搏。由于电路中每个部分电压要求不一致，大多数IC为3.3V，一部分为1.8V，如果是CPU这种复杂芯片，电源电压可能更低。对于像单片机和嵌入式MCu等供电需求较小的IC来说,LDO完全可以解决他们的供电问题，但如果供电功率稍微大一些比如FPGA以及CPU大功率LED等等可能就需要用到DCDC了，DCDC相对来说效率较高,应用广泛。
{% endpaper %}
</p></div>

## 是什么

DCDC 是直流转直流的转换器，能够实现升降压。目前主流的主要分两大类，下面主要按照分类来讲：

1. 开关型稳压电源（Buck；Boost；Boost-Buck）
2. 线性稳压电源（LDO）

## 开关型稳压电源

开关型有三种：Buck；Boost；Boost-Buck。开关型效率高，但是噪声很大，在layout方面需要注意很多细节。下面主要讲解{% mark Buck；Boost color:red %}。

### Buck（降压）

下图中两个⬛️上面分别写着`BSW`和`SW`的是 IC 引脚标识，一般在规格书上都会写出来，`BSW`也有可能叫做`BOOT`或者`BSBT`，⬛️的左侧为IC内部框图，右侧为外部电路（也就是我们设计的电路）。

{% image 1.png  Buck（降压） download:1.png %}

Buck的本质是什么？通过{% mark 高速开关调节电压高低 color:red %}，那怎么调节呢，上图中有两个`MOS`，二者互斥，同一时刻只能有一个`MOS`打开，二者不同时关闭活同时开启。流程大概是-->上`MOS`开-->`SW`电压瞬间上升--下`MOS`开-->`SW`电压瞬间下降；此时`SW`输出类似于方波，但是通过LC后电压变化得缓慢，将时间轴拉长来看就像是电压在小范围中波动，近似于稳定电压，对于输入`VIN`电压降低了。

通过运放控制`H-MOS`（上面的MOS：Q1）和`L-MOS`（下面的MOS：Q2）相间通断控制输出电压高低。

#### 工作时

0. 当IC工作电源抬起时，IC开始工作，即VCC电压上升，此时`H-MOS`的$V_{GS}=VCC$，`H-MOS`正常被开启。

1. 当`H-MOS`导通，`L-MOS`截止时，紫色高亮部分电压抬高，其中`SW`引脚电压瞬间上升到VIN，电流通过`L1`、`C2` LC震荡，让瞬间上升的波形变成缓慢上升的波形，此状态一直持续到H-MOS断开。

{% image 2.png  Buck状态-1 download:2.png %}

2. 当`H-MOS`截止，`L-MOS`导通时，紫色高亮部分电压因外部电容`C2`有电而缓慢下降，其中`SW`引脚电压由于`L-MOS`的导通而接地，此时，`VCC`给自举电容`C1`充电。此状态一直持续到`L-MOS`断开。 

{% image 3.png  Buck状态-2 download:3.png %}

3. 这时为了维持右侧用电器输入电压稳定，不能继续降低上图`用电器R2的输入电压`（后面都用$V_{R2}$表示）了，我们必须使得`H-MOS`导通，此时由于`L-MOS`的关断，`SW`电压从`0V`回到了$V_{R2}$，同时电容`BSBT`端电压（下图中高亮部分）与`SW`端电压压差为`VCC`，而此时由于{% mark 电容两端电压不可突变 color:red %}，电容两端{% mark 对地压差同时 color:red %}上升了$V_{R2}$，于是`H-MOS`的$V_G=VCC+V_{R2}$，此时`H-MOS`满足了导通条件，$V_{GS}>0$，`H-MOS`导通。

{% image 4.png  Buck状态-3 download:4.png %}

4. 重复2步骤：2-->3-->2-->循环往复，不停的通断`HL-MOS`以达到调节降压的目的。

#### Layout注意事项

以下参考自[参考链接3]

{% image 5.png  Buck-layout download:5.png %}

> 1. 当输出电流IO ≤ 1A时，可以将CIN和CBYPASS用一个陶瓷电容来替代；当输出电流比较大时，则不能将这两个电容合并，并且CIN需要一个容值更大的电容，一般来说，容值越大通常意味着频率特性越差（自谐振频率越低）；CBYPASS一般采用X5R或X7R的 0.1uF~0.47 uF贴片型陶瓷电容。
> 2. CIN和CBYPASS的过孔寄生电感会使输出电压噪声显著增加。
> 3. 不要增加电感的出线线宽
> 4. 电感下方的GND铜皮要挖空
> 5. 避免电感下方的两块铜皮过近，寄生电容会直接将开关节点出的噪声直接引入至输出
> 6. 反馈网络布线是最需要注意的，如果这根线上加载了噪声，将会直接体现在输出电压上。
> 7. 在远离电感和二极管开关节点的地方出线。不要在电感器和二极管正下方布线。

### Boost（升压）

#### 仿真分享

> 网站：https://cc.xiaogd.net/

打开网页，左上角文件-->文本导入，复制以下文本。下面的仿真参数是参考MT3608的规格书做的。可以大致看个效果，实际应用中，这颗IC有反馈电压的引脚，这部分我没有仿真出来

```txt
$ 1 2.6041666666666667e-8 0.08119363461506351 51 5 43 5e-11
r 816 352 816 80 0 10000
c 640 352 640 80 0 1e-7 -8.071510880640082 -10
l 352 80 528 80 0 0.0000047 1.8721934015586417e-7 0
v 352 352 352 80 0 0 40 5 0 0 0.5
r 528 352 352 352 0 100
d 528 80 640 80 2 default
w 640 80 688 80 0
w 816 352 640 352 0
w 640 352 528 352 0
f 480 208 528 208 32 1.5 0.02
R 384 208 384 160 0 2 1200000 5 0 0 0.5
w 448 208 464 208 0
w 528 192 528 80 0
w 528 224 528 352 0
w 464 208 480 208 0
p 880 80 880 352 3 0 0
370 688 80 816 80 1 0 0
w 816 80 880 80 0
w 816 352 880 352 0
368 528 80 560 32 0 0
368 352 80 384 32 0 0
s 576 176 576 256 0 1 false
w 576 176 576 144 0
w 576 256 576 304 0
w 576 304 528 352 0
w 576 144 528 80 0
s 384 208 448 208 0 0 false
368 640 80 672 32 0 0
o 6 1 0 4099 20 0.0015625 0 2 6 3
o 5 1 0 4099 10 0.05 1 2 5 3
o 19 1 0 4099 10 12.8 2 2 19 3
o 20 1 0 4099 5 6.4 3 2 20 3
38 1 F1 0 0.000001 0.000101 -1 Capacitance
38 2 F1 0 0.01 1.01 -1 Inductance
38 0 F1 0 1 101 -1 Resistance
```

Boost同理，通过高速通断，利用电感充磁放磁，电流无法突变，电压瞬间反向，使得电源电压与电感感应电动势一起为用电器供电以达到升压作用。

#### 工作时

{% image 1.gif  boost仿真 download:1.gif %}

1. MOS打开，电源给电感充磁，同时给二极管后端电容充电。

{% image 7.png  boost-1 download:7.png %}

2. MOS关闭，电感为了维持电流而电压反向，二极管后端电路电压为$V_L+V_{VCC}$（VCC电源电压）

{% image 6.png  boost-2 download:6.png %}

3. 重复步骤1-->2-->1循环往复

关于计算方法可以参考[参考链接5]

这里讲解的相对简单，Boost我没有实际使用过，最常用的还是Buck降压。Boost相对于Buck，电流在一定范围内变化，就类似于Buck中输出电压变化。

### 线性稳压电源（LDO）

详细了解可以参考[参考链接6]

几个特性：
LDO=low dropout regulator，低压差+线性+稳压器。

- 低压差： 输出压降比较低，例如输入3.3V，输出可以达到3.2V。
- 线性： LDO内部的MOS管工作于线性电阻。
- 稳压器： 说明了LDO的用途是用来给电源稳压。

{% image 8.png LDO download:8.png %}

<div id="first_down"><p>
{% paper style:underline title:<<<文末闲语>>> author:Phosphine %}
<!-- line left -->
毕业前不论是电赛还是科创，基本都用的是LDO居多，DCDC的应用也是上班后才上手实操过，关于DCDC布局方面需要详细参考规格书，否则输出电压电流可能达不到预期效果。这次写DCDC的文章也算是对之前学习的总结，之前只知道用就完事了，但究其根本还是说不出来。凡是接触电学，总是离不开电源，Buck和Boost也只是众多电源中最基础的，还有很多值得学习...
{% endpaper %}
</p></div>

> 参考链接：
> 1. [BUCK电路的参数计算「CSDN」](https://blog.csdn.net/weixin_40379143/article/details/85267799)
> 2. [秒懂电容自举电路「知乎」](https://zhuanlan.zhihu.com/p/73283825)
> 3. [Buck DC-DC 的PCB layout](https://blog.csdn.net/luohuo9844/article/details/112627692)
> 4. [电源篇 -- 升压电路 Boost【立创社区】](https://club.szlcsc.com/article/details_43524_1.htm)
> 5. [直流电路中升压电路（Boost）的设计原理、参数计算及MATLAB仿真「知乎」](https://zhuanlan.zhihu.com/p/588382758)
> 6. [电子电路学习笔记（14）——LDO(低压差线性稳压器)「CSDN」](https://blog.csdn.net/qq_36347513/article/details/121019508)

<!-- 
Category：

理论：理论知识技能，技术
应用：应用笔记，实操
折腾：折腾折腾折腾折腾！(其实属于应用，但就是玩！)
方法：方法论（经验谈），如工程方法
工具：针对具体工具的介绍、使用方法、分析适用场景等；使用工具如何如何解决具体问题，应该放在「应用」里
作品：自己的作品（成品）、个人项目日志等
杂谈：生活碎碎念
自然科学：物理，化学，数学
其他：没法分类的东西

Tags

细分领域：机器之脉络(硬件),机器之魂魄(嵌入式软件,机器学习，算法等),机器之骨骼(结构),
形式：日志
具体内容：个人作品、方法论、随笔
语言：python C C# Java Html micropython 微信小程序
IDE：Arduino CUBEIDE Vscode
自然科学：代数 几何 概率 黑洞 白矮星 四维空间...
IC OR IDE : STM32 ESP32 ESP8266 C51 树莓派 RK3399 野火开发版 MIQI
模组：ws2812b
系统：Linux Windows macOS openwrt Docker   termux
游戏：MC
博客：hexo 主题 魔改
折腾系类：黑苹果，整服务器，termux

 -->


