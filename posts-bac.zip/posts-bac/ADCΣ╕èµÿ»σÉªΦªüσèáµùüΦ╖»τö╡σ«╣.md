---
title: ADC上是否要加旁路电容
cover: /headimg/headimg/headimg_9.jpg
banner: /headimg/headimg/headimg_9.jpg
thumbnail: /headimg/headimg/headimg_9.jpg
index_img: /headimg/headimg/headimg_9.jpg
banner_img: /headimg/headimg/headimg_9.jpg
poster:
  topic: null
  headline: null
  caption: null
  color: null
tags:
  - ADC
categories:
  - 应用
date: 2024-05-08 05:43:33
topic: e-sth
---

<div id="first_down"><p>
{% paper style:underline title:<<<写在前面>>> author:Phosphine %}
<!-- line left -->
之所以写这篇博客，是调试能源卡程序的时候发现ADC的数值总是高了那么一点，而且如果循环检测时，两次检测读取的时间必须大于1000ms，否则会出现读取数据无变化的情况。但是用示波器或者万用表点ADC这条线，不需要延时1000ms也能够快速响应进行ADC检测了。上网查阅了相关信息初步得出一个结论：{% mark ADC硬件线路最好加上旁路电容 %}，否则会出现上述情况。
{% endpaper %}
</p></div>

## 参考
电池电压检测在ADC引脚采样，使用旁路电容可以降低噪声。实际测量中发现，为添加时，电压略微偏高，添加电容后电压稳定。

{% link https://www.cnblogs.com/sunshine-jackie/p/8324709.html 电容（2）旁路电容工作原理深度解析 %}

{% link https://blog.csdn.net/challenglistic/article/details/132311833 【STM32学习】ADC（一）—— STM32 内置 AD 模块框图 %}

## 添加旁路电容的原因

> 高低电平变换时间越短，则产生的谐波（高频）成分越丰富，因此，低速开关并不意味着高频成分少，信号频率为1MHz方波存在的高频谐波成分比同频率正弦波要高得多，因为方波的高低电平切换时间非常短，而正弦波则相对非常缓慢。【[电容（2）旁路电容工作原理深度解析](https://www.cnblogs.com/sunshine-jackie/p/8324709.html)】

{% image 1.png adc download:1.png %}

简单来说，STM32（其他MCU应该也是类似的）ADC通过开关打开，连接之后就可以通过运放检测电压了，这是开关打开与关闭就像上面所说，低速开关并不意味着高频成分少，自然会产生高频噪声，这是旁路电容就起到了除噪声的作用，[参考链接](https://www.cnblogs.com/sunshine-jackie/p/8324709.html)中说到，IC中存在大量运放，所有的VDD全部同源时，这样的高频信号叠加起来便会产生杂乱的噪声，影响VDD原本干净的电压。

> 也就是说，其它门的噪声电压（也称为共路噪声）被传递到门A的输出端，同一时间逻辑切换越多则产生的共路噪声越大，一旦叠加在VDD上的共路噪声超过芯片的噪声容限，电路因无法有效地判断高低电平而导致异常【[电容（2）旁路电容工作原理深度解析](https://www.cnblogs.com/sunshine-jackie/p/8324709.html)】



<!-- 
Category：

理论：理论知识技能，技术
应用：应用笔记，实操
折腾：折腾折腾折腾折腾！(其实属于应用，但就是玩！)
方法：方法论（经验谈），如工程方法
工具：针对具体工具的介绍、使用方法、分析适用场景等；使用工具如何如何解决具体问题，应该放在「应用」里
作品：自己的作品（成品）、个人项目日志等
杂谈：生活碎碎念
自然科学：物理，化学，数学
其他：没法分类的东西

Tags

细分领域：机器之脉络(硬件),机器之魂魄(嵌入式软件,机器学习，算法等),机器之骨骼(结构),
形式：日志
具体内容：个人作品、方法论、随笔
语言：python C C# Java Html micropython 微信小程序
IDE：Arduino CUBEIDE Vscode
自然科学：代数 几何 概率 黑洞 白矮星 四维空间...
IC OR IDE : STM32 ESP32 ESP8266 C51 树莓派 RK3399 野火开发版 MIQI
模组：ws2812b
系统：Linux Windows macOS openwrt Docker   termux
游戏：MC
博客：hexo 主题 魔改
折腾系类：黑苹果，整服务器，termux

 -->


