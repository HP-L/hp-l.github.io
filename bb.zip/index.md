---
title: 三白的Hexo短博文
date: 2021-04-25 00:56:56
cover: BBtalk.png
---

👉🏼此短博文通过📱手机微信发出，主要记录碎片化思考和动态。📑


<!-- 存放哔哔的容器 -->
<div id="bbtalk"></div>
<!-- 引用 bbtalk -->

<script src="./bbtalk.min.js"></script>
<script>
bbtalk.init({
  appId: "jef4t2ru1vk2vvuAOdhLUdbf-gzGzoHsz",
  appKey: "Vzrh6DrOFFALSJh2bM40w0C2",
  serverURLs: 'https://jef4t2ru.lc-cn-n1-shared.com'
})
</script>